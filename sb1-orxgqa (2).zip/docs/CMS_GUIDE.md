# RealtyHub CMS Management Guide

## Table of Contents
1. [Accessing the CMS](#accessing-the-cms)
2. [Content Management](#content-management)
3. [User Management](#user-management)
4. [SEO Management](#seo-management)
5. [Media Library](#media-library)
6. [Analytics & Reports](#analytics--reports)
7. [System Settings](#system-settings)

## Accessing the CMS

### Admin Access
1. Navigate to `/admin` in your browser
2. Login with admin credentials
3. Default admin route is protected and requires authentication

### User Roles & Permissions
- **Super Admin**: Full access to all features
- **Content Manager**: Manage listings, users, and content
- **Editor**: Edit and publish content
- **Moderator**: Review and moderate content

## Content Management

### Listing Management
1. **Creating Listings**
   - Navigate to "Listings" → "Add New"
   - Fill required fields:
     - Title
     - Description
     - Price
     - Location
     - Images
   - Set listing status (Draft/Published)
   - Configure visibility and featured status

2. **Editing Listings**
   - Access existing listings from the dashboard
   - Modify content and metadata
   - Update images and attachments
   - Change listing status

3. **Bulk Actions**
   - Select multiple listings
   - Apply actions:
     - Delete
     - Change status
     - Update categories
     - Modify visibility

### Category Management
1. **Creating Categories**
   ```
   Categories → Add New
   - Name
   - Slug (auto-generated)
   - Description
   - Parent category (optional)
   ```

2. **Organizing Categories**
   - Drag and drop to reorder
   - Create hierarchical structure
   - Set display options

## User Management

### Managing Users
1. **User List View**
   - View all users
   - Filter by role, status
   - Search functionality

2. **User Actions**
   - Create new users
   - Edit user details
   - Suspend/activate accounts
   - Reset passwords

3. **Role Management**
   - Assign roles
   - Modify permissions
   - Create custom roles

### Agency Management
1. **Agency Verification**
   - Review verification requests
   - Check submitted documents
   - Approve/reject applications

2. **Agency Settings**
   - Configure agency profiles
   - Set listing limits
   - Manage subscription status

## SEO Management

### Page SEO
1. **Meta Information**
   - Title tags
   - Meta descriptions
   - Keywords
   - OG tags

2. **URL Management**
   - Configure URL structure
   - Set redirects
   - Manage canonical URLs

### Schema Markup
1. **Schema Types**
   - RealEstate
   - LocalBusiness
   - Organization

2. **Implementation**
   ```json
   {
     "@type": "RealEstateListing",
     "name": "Property Title",
     "description": "Property Description",
     "price": "$XXX,XXX",
     "address": {
       "@type": "PostalAddress",
       "streetAddress": "...",
       "addressLocality": "...",
       "addressRegion": "...",
       "postalCode": "..."
     }
   }
   ```

## Media Library

### Asset Management
1. **Upload Media**
   - Drag and drop interface
   - Bulk upload support
   - Automatic optimization

2. **Organization**
   - Create folders
   - Add tags
   - Set categories

3. **Image Optimization**
   - Automatic resizing
   - Format conversion
   - Compression settings

### Usage Guidelines
1. **Image Specifications**
   - Maximum size: 10MB
   - Recommended dimensions:
     - Listings: 1200x800px
     - Thumbnails: 300x200px
   - Supported formats: JPG, PNG, WebP

2. **Storage Management**
   - Monitor usage
   - Clean unused media
   - Archive old content

## Analytics & Reports

### Dashboard Analytics
1. **Key Metrics**
   - Page views
   - User engagement
   - Listing performance
   - Conversion rates

2. **Custom Reports**
   - Generate custom reports
   - Export data
   - Schedule automated reports

### Performance Monitoring
1. **System Health**
   - Server status
   - Database performance
   - Cache efficiency

2. **User Activity**
   - Track user behavior
   - Monitor search patterns
   - Analyze engagement

## System Settings

### General Configuration
1. **Site Settings**
   ```
   Settings → General
   - Site title
   - Timezone
   - Date format
   - Language
   ```

2. **Email Settings**
   ```
   Settings → Email
   - SMTP configuration
   - Email templates
   - Notification settings
   ```

### Security Settings
1. **Access Control**
   - IP whitelisting
   - 2FA setup
   - Session management

2. **Backup Settings**
   - Automated backups
   - Backup frequency
   - Storage location

## Best Practices

### Content Management
1. **Quality Guidelines**
   - Use high-quality images
   - Write detailed descriptions
   - Maintain consistent formatting

2. **Workflow**
   - Review content before publishing
   - Use draft status for work in progress
   - Schedule content updates

### SEO Optimization
1. **Content Guidelines**
   - Use descriptive titles
   - Write unique descriptions
   - Include relevant keywords

2. **Technical SEO**
   - Monitor page speed
   - Check mobile responsiveness
   - Verify schema markup

### Security
1. **Account Security**
   - Regular password updates
   - Use strong passwords
   - Enable 2FA when available

2. **Content Security**
   - Regular backups
   - Access logging
   - File scanning

## Troubleshooting

### Common Issues
1. **Image Upload Failures**
   - Check file size
   - Verify format support
   - Check storage space

2. **Performance Issues**
   - Clear cache
   - Optimize database
   - Check server resources

### Support Resources
1. **Documentation**
   - Online help center
   - API documentation
   - User guides

2. **Technical Support**
   - Support ticket system
   - Emergency contacts
   - Knowledge base

## Updates & Maintenance

### Update Process
1. **System Updates**
   - Schedule maintenance
   - Test in staging
   - Backup before updates

2. **Content Updates**
   - Regular content review
   - Update outdated information
   - Archive old content

### Maintenance Schedule
1. **Daily Tasks**
   - Monitor system health
   - Review user reports
   - Backup verification

2. **Weekly Tasks**
   - Content review
   - Performance analysis
   - Security checks

3. **Monthly Tasks**
   - Full system backup
   - Analytics review
   - User access audit