# Local Development and Functionalization Guide

## Table of Contents
1. [Local Infrastructure Setup](#local-infrastructure-setup)
2. [Development Environment](#development-environment)
3. [Step-by-Step Functionalization](#step-by-step-functionalization)
4. [Testing Guide](#testing-guide)
5. [Troubleshooting](#troubleshooting)

## Local Infrastructure Setup

### Prerequisites Installation

```bash
# 1. Install Node.js (v18+)
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# 2. Install PostgreSQL
sudo apt install postgresql postgresql-contrib

# 3. Install Redis
sudo apt install redis-server

# 4. Install Docker (optional, for containerization)
curl -fsSL https://get.docker.com | sudo bash
sudo usermod -aG docker $USER

# 5. Install development tools
npm install -g typescript ts-node nodemon
```

### Database Setup

```bash
# PostgreSQL setup
sudo -u postgres psql

# Create database and user
CREATE DATABASE realtyhub_dev;
CREATE USER realtyhub WITH ENCRYPTED PASSWORD 'your_password';
GRANT ALL PRIVILEGES ON DATABASE realtyhub_dev TO realtyhub;

# Redis configuration
sudo systemctl start redis-server
sudo systemctl enable redis-server
```

### Environment Configuration

Create `.env.local` file in project root:

```env
# Application
NODE_ENV=development
PORT=3000
FRONTEND_URL=http://localhost:5173
API_URL=http://localhost:3000/api

# Database
DATABASE_URL=postgresql://realtyhub:your_password@localhost:5432/realtyhub_dev
REDIS_URL=redis://localhost:6379

# Authentication
JWT_SECRET=your_local_secret_key
JWT_EXPIRES_IN=7d

# Storage (local development)
STORAGE_TYPE=local
UPLOAD_DIR=./uploads

# Email (use ethereal for local development)
SMTP_HOST=smtp.ethereal.email
SMTP_PORT=587
SMTP_USER=your_ethereal_user
SMTP_PASS=your_ethereal_password

# Feature flags
ENABLE_WEBSOCKETS=true
ENABLE_SEARCH=true
ENABLE_NOTIFICATIONS=true
```

## Development Environment

### Project Setup

```bash
# 1. Clone repository
git clone [repository-url]
cd realtyhub

# 2. Install dependencies
npm install

# 3. Initialize database
npx prisma migrate dev
npx prisma db seed

# 4. Start development servers
npm run dev          # Frontend (Vite)
npm run server:dev   # Backend (Node.js)
```

### Development Scripts

Add to `package.json`:

```json
{
  "scripts": {
    "dev": "vite",
    "server:d