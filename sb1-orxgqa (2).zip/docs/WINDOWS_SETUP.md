# Windows Local Development Setup Guide

## Prerequisites Installation

### 1. Required Software

1. **Node.js**
   - Download Node.js 18.x LTS from [nodejs.org](https://nodejs.org/)
   - Run the installer and follow the setup wizard
   - Verify installation:
     ```bash
     node --version
     npm --version
     ```

2. **PostgreSQL**
   - Download PostgreSQL 14.x from [postgresql.org](https://www.postgresql.org/download/windows/)
   - During installation:
     - Remember the password you set for the postgres user
     - Keep default port (5432)
     - Install pgAdmin (included in installer)

3. **Redis Cloud Setup** (Instead of local Redis)
   - Go to [Redis Cloud](https://redis.com/try-free/)
   - Sign up for a free account
   - Create a new subscription
   - Create a new database
   - Save the connection details:
     - Endpoint URL
     - Port
     - Password

4. **VS Code**
   - Download from [code.visualstudio.com](https://code.visualstudio.com/)
   - Install recommended extensions:
     - ESLint
     - Prettier
     - TypeScript and JavaScript Language Features
     - Tailwind CSS IntelliSense

### 2. Environment Setup

1. **Create Project Directory**
   ```bash
   mkdir realtyhub
   cd realtyhub
   ```

2. **Clone Repository**
   ```bash
   git clone [repository-url] .
   ```

3. **Create Environment Files**

Create `.env` in the project root:
```env
# Application
NODE_ENV=development
PORT=3000
FRONTEND_URL=http://localhost:5173
API_URL=http://localhost:3000/api

# Database
DATABASE_URL=postgresql://postgres:your_password@localhost:5432/realtyhub_dev

# Redis Cloud
REDIS_URL=redis://default:your_password@your_host.cloud.redislabs.com:your_port

# Authentication
JWT_SECRET=your_dev_secret_key
JWT_EXPIRES_IN=7d

# Storage
STORAGE_TYPE=local
UPLOAD_DIR=./uploads

# Email (for development)
SMTP_HOST=smtp.ethereal.email
SMTP_PORT=587
SMTP_USER=your_ethereal_email
SMTP_PASS=your_ethereal_password
```

## Project Setup

### 1. Database Setup

1. **Open pgAdmin 4**
   - Connect to PostgreSQL server
   - Right-click Databases → Create → Database
   - Name: `realtyhub_dev`

2. **Create Database User**
   - Open SQL Tool
   - Run:
     ```sql
     CREATE USER realtyhub WITH ENCRYPTED PASSWORD 'your_password';
     GRANT ALL PRIVILEGES ON DATABASE realtyhub_dev TO realtyhub;
     ```

### 2. Install Dependencies

```bash
# Install project dependencies
npm install

# Install global tools
npm install -g typescript ts-node nodemon
```

### 3. Database Migration

```bash
# Generate Prisma client
npx prisma generate

# Run migrations
npx prisma migrate dev

# Seed database (if needed)
npx prisma db seed
```

## Running the Application

### 1. Start Backend Server

```bash
# Terminal 1 - Start backend
npm run server:dev
```

### 2. Start Frontend Development Server

```bash
# Terminal 2 - Start frontend
npm run dev
```

### 3. Verify Setup

1. Frontend: Open http://localhost:5173
2. Backend: Open http://localhost:3000/api/health
3. Database: Use pgAdmin to verify tables are created
4. Redis: Check backend logs for successful connection

## Development Workflow

### 1. Code Organization
```
src/
├── components/    # React components
├── pages/         # Page components
├── server/        # Backend code
├── services/      # API services
├── store/         # State management
└── utils/         # Utility functions
```

### 2. Available Scripts

```bash
# Start frontend development server
npm run dev

# Start backend development server
npm run server:dev

# Run tests
npm run test

# Build for production
npm run build

# Type checking
npm run type-check

# Lint code
npm run lint
```

## Troubleshooting Common Issues

### 1. Port Conflicts
If ports are already in use:
```bash
# Find process using port
netstat -ano | findstr :3000

# Kill process
taskkill /PID [process_id] /F
```

### 2. Database Connection Issues
- Verify PostgreSQL service is running:
  ```bash
  # Open Services app
  services.msc
  # Find "PostgreSQL" service and ensure it's running
  ```
- Check connection string in `.env`
- Verify database user permissions

### 3. Node.js Issues
```bash
# Clear npm cache
npm cache clean --force

# Remove node_modules and reinstall
rd /s /q node_modules
del package-lock.json
npm install
```

### 4. TypeScript Errors
- Verify TypeScript version:
  ```bash
  tsc --version
  ```
- Rebuild TypeScript:
  ```bash
  npm run build:ts
  ```

## Development Tips

### 1. VS Code Setup

Create `.vscode/settings.json`:
```json
{
  "editor.formatOnSave": true,
  "editor.defaultFormatter": "esbenp.prettier-vscode",
  "editor.codeActionsOnSave": {
    "source.fixAll.eslint": true
  }
}
```

### 2. Git Configuration
```bash
git config --global core.autocrlf true
```

### 3. Debugging

1. **Backend Debugging**
   - Add `debugger` statements in code
   - Start with `npm run server:dev:debug`
   - Attach VS Code debugger

2. **Frontend Debugging**
   - Use React Developer Tools browser extension
   - Use Chrome DevTools
   - Check console logs

### 4. Testing

```bash
# Run all tests
npm test

# Run specific test file
npm test -- src/components/MyComponent.test.tsx

# Run tests in watch mode
npm test -- --watch
```

## Additional Resources

### Documentation
- Project documentation in `/docs`
- API documentation
- Component documentation

### Support
- GitHub Issues
- Stack Overflow
- Project Wiki

### Learning Resources
- React documentation
- TypeScript documentation
- Prisma documentation
- Tailwind CSS documentation