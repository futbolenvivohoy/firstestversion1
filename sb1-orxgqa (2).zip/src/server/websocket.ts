import { WebSocketServer } from 'ws';
import { Server } from 'http';
import jwt from 'jsonwebtoken';
import { notificationService } from './services/notification';

export const setupWebSocket = (server: Server) => {
  const wss = new WebSocketServer({ server });

  wss.on('connection', async (ws, req) => {
    try {
      // Get token from query string
      const url = new URL(req.url!, `ws://${req.headers.host}`);
      const token = url.searchParams.get('token');

      if (!token) {
        ws.close(1008, 'Token required');
        return;
      }

      // Verify token
      const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any;
      const userId = decoded.userId;

      // Register WebSocket connection
      notificationService.registerWebSocket(userId, ws);

      ws.on('message', (data) => {
        // Handle incoming messages if needed
      });

      ws.on('error', (error) => {
        console.error('WebSocket error:', error);
        ws.close(1011, 'Internal error');
      });
    } catch (error) {
      console.error('WebSocket connection error:', error);
      ws.close(1008, 'Invalid token');
    }
  });

  return wss;
};