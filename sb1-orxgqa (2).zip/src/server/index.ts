import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import { rateLimit } from 'express-rate-limit';
import { PrismaClient } from '@prisma/client';
import { authRouter } from './routes/auth';
import { listingRouter } from './routes/listings';
import { userRouter } from './routes/users';
import { messageRouter } from './routes/messages';
import { adminRouter } from './routes/admin';
import { errorHandler } from './middleware/errorHandler';
import { authenticate } from './middleware/authenticate';

const prisma = new PrismaClient();
const app = express();

// Middleware
app.use(helmet());
app.use(cors());
app.use(compression());
app.use(express.json());

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100 // limit each IP to 100 requests per windowMs
});
app.use(limiter);

// Routes
app.use('/api/auth', authRouter);
app.use('/api/listings', listingRouter);
app.use('/api/users', authenticate, userRouter);
app.use('/api/messages', authenticate, messageRouter);
app.use('/api/admin', authenticate, adminRouter);

// Error handling
app.use(errorHandler);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});