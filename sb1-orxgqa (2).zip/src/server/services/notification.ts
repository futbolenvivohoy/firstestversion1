import { PrismaClient } from '@prisma/client';
import { sendEmail } from './email';
import { WebSocket } from 'ws';

const prisma = new PrismaClient();
const clients = new Map<string, WebSocket>();

export const notificationService = {
  async createNotification(userId: string, type: string, data: any) {
    const notification = await prisma.notification.create({
      data: {
        userId,
        type,
        data,
        read: false
      }
    });

    // Send real-time notification if user is connected
    const ws = clients.get(userId);
    if (ws) {
      ws.send(JSON.stringify(notification));
    }

    // Send email notification based on user preferences
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: { notificationPreferences: true }
    });

    if (user?.notificationPreferences?.email) {
      await sendEmail(user.email, type, data);
    }

    return notification;
  },

  registerWebSocket(userId: string, ws: WebSocket) {
    clients.set(userId, ws);
    ws.on('close', () => clients.delete(userId));
  }
};