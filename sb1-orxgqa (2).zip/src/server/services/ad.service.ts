import { PrismaClient } from '@prisma/client';
import { paymentService } from './payment';

const prisma = new PrismaClient();

export const adService = {
  async createCampaign(userId: string, data: {
    title: string;
    budget: number;
    startDate: Date;
    endDate: Date;
    listingIds: string[];
  }) {
    const campaign = await prisma.adCampaign.create({
      data: {
        userId,
        title: data.title,
        budget: data.budget,
        startDate: data.startDate,
        endDate: data.endDate,
        status: 'PENDING',
        metrics: {}
      }
    });

    // Create payment intent
    const paymentIntent = await paymentService.createPaymentIntent(
      data.budget * 100, // Convert to cents
      'eur'
    );

    return { campaign, paymentIntent };
  },

  async updateCampaignStatus(campaignId: string, status: string) {
    return prisma.adCampaign.update({
      where: { id: campaignId },
      data: { status }
    });
  },

  async updateCampaignMetrics(campaignId: string, metrics: any) {
    return prisma.adCampaign.update({
      where: { id: campaignId },
      data: { metrics }
    });
  },

  async getCampaignAnalytics(campaignId: string) {
    const campaign = await prisma.adCampaign.findUnique({
      where: { id: campaignId }
    });

    if (!campaign) throw new Error('Campaign not found');

    return {
      impressions: campaign.metrics?.impressions || 0,
      clicks: campaign.metrics?.clicks || 0,
      ctr: campaign.metrics?.ctr || 0,
      spend: campaign.metrics?.spend || 0
    };
  }
};