import { PrismaClient } from '@prisma/client';
import { createClient } from 'redis';

const prisma = new PrismaClient();
const redis = createClient({
  url: process.env.REDIS_URL
});

export const recommendationService = {
  async getPersonalizedRecommendations(userId: string) {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: {
        viewedListings: true,
        favoriteListings: true
      }
    });

    if (!user) return [];

    // Get user preferences
    const preferences = await this.getUserPreferences(user);

    // Find similar listings
    const recommendations = await prisma.listing.findMany({
      where: {
        AND: [
          { category: { in: preferences.categories } },
          { city: { in: preferences.cities } },
          { price: { 
            gte: preferences.priceRange.min,
            lte: preferences.priceRange.max
          }}
        ]
      },
      orderBy: {
        views: 'desc'
      },
      take: 10
    });

    return recommendations;
  },

  async getSimilarListings(listingId: string) {
    const listing = await prisma.listing.findUnique({
      where: { id: listingId }
    });

    if (!listing) return [];

    return prisma.listing.findMany({
      where: {
        AND: [
          { category: listing.category },
          { city: listing.city },
          { price: {
            gte: listing.price * 0.8,
            lte: listing.price * 1.2
          }},
          { id: { not: listingId }}
        ]
      },
      orderBy: {
        views: 'desc'
      },
      take: 4
    });
  },

  async trackUserPreference(userId: string, listingId: string, action: 'view' | 'favorite') {
    const key = `user:${userId}:preferences`;
    await redis.hincrby(key, `listing:${listingId}`, action === 'view' ? 1 : 5);
  },

  private async getUserPreferences(user: any) {
    const viewedCategories = user.viewedListings.map((l: any) => l.category);
    const favoritedCategories = user.favoriteListings.map((l: any) => l.category);
    
    const categories = [...new Set([...viewedCategories, ...favoritedCategories])];
    const cities = [...new Set(user.viewedListings.map((l: any) => l.city))];
    
    const prices = user.viewedListings.map((l: any) => l.price);
    const avgPrice = prices.reduce((a: number, b: number) => a + b, 0) / prices.length;

    return {
      categories,
      cities,
      priceRange: {
        min: avgPrice * 0.7,
        max: avgPrice * 1.3
      }
    };
  }
};