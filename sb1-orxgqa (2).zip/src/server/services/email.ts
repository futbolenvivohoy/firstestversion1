import nodemailer from 'nodemailer';
import { EmailTemplate } from '../types';
import { renderTemplate } from '../utils/templateRenderer';

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: parseInt(process.env.SMTP_PORT!),
  secure: true,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS
  }
});

export const emailService = {
  async sendEmail(to: string, template: EmailTemplate, data: any) {
    const { subject, html } = await renderTemplate(template, data);

    await transporter.sendMail({
      from: process.env.SMTP_FROM,
      to,
      subject,
      html
    });
  },

  async sendVerificationEmail(email: string, token: string) {
    await this.sendEmail(email, 'verification', {
      verificationUrl: `${process.env.FRONTEND_URL}/verify-email?token=${token}`
    });
  },

  async sendPasswordResetEmail(email: string, token: string) {
    await this.sendEmail(email, 'password-reset', {
      resetUrl: `${process.env.FRONTEND_URL}/reset-password?token=${token}`
    });
  },

  async sendListingApprovedEmail(email: string, listingId: string) {
    await this.sendEmail(email, 'listing-approved', {
      listingUrl: `${process.env.FRONTEND_URL}/listing/${listingId}`
    });
  },

  async sendNewMessageEmail(email: string, data: {
    senderName: string;
    messagePreview: string;
    threadId: string;
  }) {
    await this.sendEmail(email, 'new-message', {
      ...data,
      threadUrl: `${process.env.FRONTEND_URL}/messages/${data.threadId}`
    });
  }
};