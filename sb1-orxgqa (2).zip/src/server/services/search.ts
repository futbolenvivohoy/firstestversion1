import { PrismaClient } from '@prisma/client';
import { Client } from '@elastic/elasticsearch';

const prisma = new PrismaClient();
const elasticsearch = new Client({ node: process.env.ELASTICSEARCH_URL });

export const searchService = {
  async search(query: string, filters: any) {
    const { category, city, priceMin, priceMax, sortBy } = filters;

    const must: any[] = [
      {
        multi_match: {
          query,
          fields: ['title^2', 'description', 'features']
        }
      }
    ];

    if (category) {
      must.push({ term: { category } });
    }
    if (city) {
      must.push({ term: { city } });
    }
    if (priceMin || priceMax) {
      must.push({
        range: {
          price: {
            gte: priceMin,
            lte: priceMax
          }
        }
      });
    }

    const { body } = await elasticsearch.search({
      index: 'listings',
      body: {
        query: {
          bool: { must }
        },
        sort: this.getSortOptions(sortBy)
      }
    });

    return body.hits.hits.map((hit: any) => ({
      ...hit._source,
      score: hit._score
    }));
  },

  async getSuggestions(query: string) {
    const { body } = await elasticsearch.search({
      index: 'listings',
      body: {
        suggest: {
          title_suggestions: {
            prefix: query,
            completion: {
              field: 'title_suggest',
              size: 5
            }
          }
        }
      }
    });

    return body.suggest.title_suggestions[0].options;
  },

  private getSortOptions(sortBy: string) {
    switch (sortBy) {
      case 'price_asc':
        return [{ price: 'asc' }];
      case 'price_desc':
        return [{ price: 'desc' }];
      case 'date':
        return [{ createdAt: 'desc' }];
      default:
        return ['_score'];
    }
  }
};