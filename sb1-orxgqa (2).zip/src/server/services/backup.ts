import { S3Client, PutObjectCommand, GetObjectCommand } from '@aws-sdk/client-s3';
import { PrismaClient } from '@prisma/client';
import { createGzip } from 'zlib';
import { promisify } from 'util';
import { pipeline } from 'stream';

const prisma = new PrismaClient();
const s3 = new S3Client({
  region: process.env.AWS_REGION,
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID!,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY!
  }
});

const pipe = promisify(pipeline);

export const backupService = {
  async createBackup() {
    const timestamp = new Date().toISOString();
    const backupData = await this.gatherBackupData();
    
    const gzip = createGzip();
    const backupStream = JSON.stringify(backupData);
    
    await pipe(
      backupStream,
      gzip,
      s3.send(
        new PutObjectCommand({
          Bucket: process.env.AWS_BACKUP_BUCKET!,
          Key: `backup-${timestamp}.json.gz`,
          Body: gzip,
          ContentType: 'application/gzip'
        })
      )
    );

    return {
      timestamp,
      size: backupStream.length,
      location: `backup-${timestamp}.json.gz`
    };
  },

  async restoreBackup(backupId: string) {
    const { Body } = await s3.send(
      new GetObjectCommand({
        Bucket: process.env.AWS_BACKUP_BUCKET!,
        Key: backupId
      })
    );

    const backupData = JSON.parse(await Body!.transformToString());
    await this.restoreData(backupData);
  },

  private async gatherBackupData() {
    return {
      users: await prisma.user.findMany(),
      listings: await prisma.listing.findMany(),
      messages: await prisma.message.findMany(),
      categories: await prisma.category.findMany(),
      // Add other relevant data
    };
  },

  private async restoreData(data: any) {
    await prisma.$transaction([
      prisma.user.createMany({ data: data.users }),
      prisma.listing.createMany({ data: data.listings }),
      prisma.message.createMany({ data: data.messages }),
      prisma.category.createMany({ data: data.categories }),
      // Restore other data
    ]);
  }
};