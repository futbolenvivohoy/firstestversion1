import { PrismaClient } from '@prisma/client';
import { Configuration, OpenAIApi } from 'openai';

const prisma = new PrismaClient();
const openai = new OpenAIApi(
  new Configuration({
    apiKey: process.env.OPENAI_API_KEY
  })
);

export const moderationService = {
  async moderateContent(content: string) {
    const response = await openai.createModeration({
      input: content
    });

    const result = response.data.results[0];
    return {
      flagged: result.flagged,
      categories: result.categories,
      scores: result.category_scores
    };
  },

  async moderateImage(imageUrl: string) {
    // Implement image moderation using AWS Rekognition or similar
    const rekognition = new AWS.Rekognition();
    const response = await rekognition.detectModerationLabels({
      Image: {
        Bytes: await this.getImageBuffer(imageUrl)
      }
    }).promise();

    return {
      flagged: response.ModerationLabels!.length > 0,
      labels: response.ModerationLabels
    };
  },

  async handleReport(reportId: string, action: 'approve' | 'reject') {
    const report = await prisma.report.findUnique({
      where: { id: reportId },
      include: { content: true }
    });

    if (!report) throw new Error('Report not found');

    if (action === 'reject') {
      await prisma.content.update({
        where: { id: report.contentId },
        data: { status: 'REMOVED' }
      });
    }

    await prisma.report.update({
      where: { id: reportId },
      data: { status: action === 'approve' ? 'RESOLVED' : 'REJECTED' }
    });
  },

  private async getImageBuffer(url: string) {
    const response = await fetch(url);
    return Buffer.from(await response.arrayBuffer());
  }
};