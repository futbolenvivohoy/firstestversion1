import { RecaptchaEnterpriseServiceClient } from '@google-cloud/recaptcha-enterprise';

const client = new RecaptchaEnterpriseServiceClient();

export const captchaService = {
  async verify(token: string, action: string) {
    try {
      const projectPath = client.projectPath(process.env.GOOGLE_PROJECT_ID!);
      
      const request = {
        parent: projectPath,
        assessment: {
          event: {
            token,
            siteKey: process.env.RECAPTCHA_SITE_KEY,
            expectedAction: action,
          },
        },
      };

      const [assessment] = await client.createAssessment(request);
      
      return {
        valid: assessment.tokenProperties?.valid,
        score: assessment.riskAnalysis?.score,
        action: assessment.tokenProperties?.action,
      };
    } catch (error) {
      console.error('reCAPTCHA verification failed:', error);
      return { valid: false, score: 0 };
    }
  }
};