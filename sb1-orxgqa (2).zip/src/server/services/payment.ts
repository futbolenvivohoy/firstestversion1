import Stripe from 'stripe';
import { PrismaClient } from '@prisma/client';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2023-10-16'
});
const prisma = new PrismaClient();

export const paymentService = {
  async createPaymentIntent(amount: number, currency: string = 'eur') {
    return stripe.paymentIntents.create({
      amount,
      currency
    });
  },

  async createSubscription(userId: string, priceId: string) {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: { stripeCustomer: true }
    });

    if (!user?.stripeCustomer) {
      throw new Error('User has no associated Stripe customer');
    }

    return stripe.subscriptions.create({
      customer: user.stripeCustomer.stripeCustomerId,
      items: [{ price: priceId }],
      payment_behavior: 'default_incomplete',
      expand: ['latest_invoice.payment_intent']
    });
  },

  async handleWebhook(event: Stripe.Event) {
    switch (event.type) {
      case 'payment_intent.succeeded':
        const paymentIntent = event.data.object as Stripe.PaymentIntent;
        await this.handleSuccessfulPayment(paymentIntent);
        break;
      
      case 'subscription.created':
        const subscription = event.data.object as Stripe.Subscription;
        await this.handleSubscriptionCreated(subscription);
        break;
    }
  },

  private async handleSuccessfulPayment(paymentIntent: Stripe.PaymentIntent) {
    // Update listing status, create featured listing, etc.
    const { listingId } = paymentIntent.metadata;
    if (listingId) {
      await prisma.listing.update({
        where: { id: listingId },
        data: { featured: true }
      });
    }
  },

  private async handleSubscriptionCreated(subscription: Stripe.Subscription) {
    const { userId } = subscription.metadata;
    if (userId) {
      await prisma.user.update({
        where: { id: userId },
        data: { subscriptionStatus: 'active' }
      });
    }
  }
};