import { Router } from 'express';
import { PrismaClient } from '@prisma/client';
import multer from 'multer';
import { authenticate } from '../middleware/authenticate';
import { optimizeImage, uploadToS3 } from '../services/storage';
import { moderateContent } from '../services/moderation';

const router = Router();
const prisma = new PrismaClient();
const upload = multer({ storage: multer.memoryStorage() });

router.post('/', authenticate, upload.array('images', 10), async (req, res) => {
  try {
    const { title, description, price, category, city, neighborhood, features } = req.body;
    const files = req.files as Express.Multer.File[];

    // Moderate content
    const moderationResult = await moderateContent(`${title}\n${description}`);
    if (moderationResult.flagged) {
      return res.status(400).json({ message: 'Content violates guidelines' });
    }

    // Process and upload images
    const imageUrls = await Promise.all(
      files.map(async (file, index) => {
        const optimized = await optimizeImage(file.buffer);
        const url = await uploadToS3(optimized, `listings/${req.user.id}/${Date.now()}-${index}`);
        return { url, order: index };
      })
    );

    const listing = await prisma.listing.create({
      data: {
        userId: req.user.id,
        title,
        description,
        price: parseFloat(price),
        category,
        city,
        neighborhood,
        features,
        images: {
          create: imageUrls
        }
      },
      include: {
        images: true
      }
    });

    res.json(listing);
  } catch (error) {
    res.status(500).json({ message: 'Failed to create listing' });
  }
});

router.get('/', async (req, res) => {
  try {
    const {
      category,
      city,
      priceMin,
      priceMax,
      status = 'ACTIVE',
      page = 1,
      limit = 20
    } = req.query;

    const where = {
      status,
      ...(category && { category }),
      ...(city && { city }),
      ...(priceMin && { price: { gte: parseFloat(priceMin as string) } }),
      ...(priceMax && { price: { lte: parseFloat(priceMax as string) } })
    };

    const [listings, total] = await Promise.all([
      prisma.listing.findMany({
        where,
        include: {
          images: true,
          user: {
            include: {
              profile: true
            }
          }
        },
        skip: (parseInt(page as string) - 1) * parseInt(limit as string),
        take: parseInt(limit as string)
      }),
      prisma.listing.count({ where })
    ]);

    res.json({
      listings,
      total,
      pages: Math.ceil(total / parseInt(limit as string))
    });
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch listings' });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const listing = await prisma.listing.findUnique({
      where: { id: req.params.id },
      include: {
        images: true,
        user: {
          include: {
            profile: true
          }
        },
        reviews: {
          include: {
            user: {
              include: {
                profile: true
              }
            }
          }
        }
      }
    });

    if (!listing) {
      return res.status(404).json({ message: 'Listing not found' });
    }

    // Increment view count
    await prisma.listing.update({
      where: { id: req.params.id },
      data: { views: { increment: 1 } }
    });

    res.json(listing);
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch listing' });
  }
});

export { router as listingRouter };