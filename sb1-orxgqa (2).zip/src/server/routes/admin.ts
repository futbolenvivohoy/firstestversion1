import { Router } from 'express';
import { PrismaClient } from '@prisma/client';
import { authenticate } from '../middleware/authenticate';
import { authorize } from '../middleware/authorize';
import { analyticsService } from '../services/analytics';
import { moderationService } from '../services/moderation';

const router = Router();
const prisma = new PrismaClient();

// User Management
router.get('/users', authenticate, authorize(['ADMIN']), async (req, res) => {
  try {
    const users = await prisma.user.findMany({
      include: {
        profile: true,
        listings: {
          select: {
            id: true,
            status: true
          }
        }
      }
    });
    res.json(users);
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch users' });
  }
});

router.put('/users/:id/status', authenticate, authorize(['ADMIN']), async (req, res) => {
  try {
    const { status } = req.body;
    const user = await prisma.user.update({
      where: { id: req.params.id },
      data: { status }
    });
    res.json(user);
  } catch (error) {
    res.status(500).json({ message: 'Failed to update user status' });
  }
});

// Listing Management
router.get('/listings/pending', authenticate, authorize(['ADMIN']), async (req, res) => {
  try {
    const listings = await prisma.listing.findMany({
      where: { status: 'PENDING' },
      include: {
        user: {
          include: {
            profile: true
          }
        },
        images: true
      }
    });
    res.json(listings);
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch pending listings' });
  }
});

router.put('/listings/:id/approve', authenticate, authorize(['ADMIN']), async (req, res) => {
  try {
    const listing = await prisma.listing.update({
      where: { id: req.params.id },
      data: { status: 'ACTIVE' }
    });
    res.json(listing);
  } catch (error) {
    res.status(500).json({ message: 'Failed to approve listing' });
  }
});

// Analytics
router.get('/analytics', authenticate, authorize(['ADMIN']), async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    const analytics = await analyticsService.getAnalytics({
      startDate: startDate as string,
      endDate: endDate as string
    });
    res.json(analytics);
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch analytics' });
  }
});

// Moderation
router.get('/moderation/queue', authenticate, authorize(['ADMIN']), async (req, res) => {
  try {
    const reports = await prisma.report.findMany({
      where: { status: 'PENDING' },
      include: {
        content: true,
        reporter: {
          include: {
            profile: true
          }
        }
      }
    });
    res.json(reports);
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch moderation queue' });
  }
});

router.post('/moderation/reports/:id/resolve', authenticate, authorize(['ADMIN']), async (req, res) => {
  try {
    const { action } = req.body;
    await moderationService.handleReport(req.params.id, action);
    res.json({ message: 'Report resolved successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Failed to resolve report' });
  }
});

// Category Management
router.post('/categories', authenticate, authorize(['ADMIN']), async (req, res) => {
  try {
    const category = await prisma.category.create({
      data: req.body
    });
    res.json(category);
  } catch (error) {
    res.status(500).json({ message: 'Failed to create category' });
  }
});

router.put('/categories/:id', authenticate, authorize(['ADMIN']), async (req, res) => {
  try {
    const category = await prisma.category.update({
      where: { id: req.params.id },
      data: req.body
    });
    res.json(category);
  } catch (error) {
    res.status(500).json({ message: 'Failed to update category' });
  }
});

export { router as adminRouter };