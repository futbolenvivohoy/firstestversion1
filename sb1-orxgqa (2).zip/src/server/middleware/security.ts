import helmet from 'helmet';
import { rateLimit } from 'express-rate-limit';
import { Request, Response, NextFunction } from 'express';
import { sanitizeInput } from '../utils/sanitizer';

// XSS Protection
export const xssProtection = (req: Request, res: Response, next: NextFunction) => {
  if (req.body) {
    req.body = sanitizeInput(req.body);
  }
  next();
};

// Content Security Policy
export const csp = helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", 'data:', 'https:'],
      connectSrc: ["'self'", 'https://api.example.com'],
      fontSrc: ["'self'", 'https://fonts.gstatic.com'],
      objectSrc: ["'none'"],
      mediaSrc: ["'self'"],
      frameSrc: ["'none'"],
    },
  },
});

// Rate Limiting
export const rateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // Limit each IP to 100 requests per windowMs
  message: 'Too many requests from this IP, please try again later'
});

// SQL Injection Protection
export const sqlInjectionProtection = (req: Request, res: Response, next: NextFunction) => {
  const isSuspicious = (value: string) => {
    const sqlKeywords = ['SELECT', 'INSERT', 'UPDATE', 'DELETE', 'DROP', '--'];
    return sqlKeywords.some(keyword => 
      value.toUpperCase().includes(keyword)
    );
  };

  const checkValue = (value: any) => {
    if (typeof value === 'string' && isSuspicious(value)) {
      throw new Error('Potential SQL injection detected');
    }
  };

  const checkObject = (obj: any) => {
    Object.values(obj).forEach(value => {
      if (typeof value === 'object') {
        checkObject(value);
      } else {
        checkValue(value);
      }
    });
  };

  try {
    if (req.body) checkObject(req.body);
    if (req.query) checkObject(req.query);
    if (req.params) checkObject(req.params);
    next();
  } catch (error) {
    res.status(400).json({ message: 'Invalid input detected' });
  }
};