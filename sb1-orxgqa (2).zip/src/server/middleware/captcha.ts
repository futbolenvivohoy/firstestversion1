import { Request, Response, NextFunction } from 'express';
import { captchaService } from '../services/captcha';

export const verifyCaptcha = (action: string) => {
  return async (req: Request, res: Response, next: NextFunction) => {
    try {
      const token = req.body.captchaToken;
      
      if (!token) {
        return res.status(400).json({ message: 'Captcha token required' });
      }

      const result = await captchaService.verify(token, action);
      
      if (!result.valid || (result.score && result.score < 0.5)) {
        return res.status(400).json({ message: 'Captcha verification failed' });
      }

      next();
    } catch (error) {
      res.status(500).json({ message: 'Captcha verification error' });
    }
  };
};