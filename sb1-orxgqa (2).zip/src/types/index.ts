export interface User {
  id: string;
  username: string;
  email: string;
  type: 'private' | 'agency';
  avatar?: string;
  verified: boolean;
}

export interface Listing {
  id: string;
  title: string;
  description: string;
  price: number;
  category: string;
  city: string;
  neighborhood: string;
  images: string[];
  status: 'for_rent' | 'for_lease' | 'available';
  userId: string;
  createdAt: string;
  updatedAt: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  icon: string;
}