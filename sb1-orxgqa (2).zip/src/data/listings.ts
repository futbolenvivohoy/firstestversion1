export interface Listing {
  id: string;
  image: string;
  title: string;
  location: string;
  price: number;
  category: string;
}

export const CATEGORY_LISTINGS: Record<string, Listing[]> = {
  default: [
    {
      id: '1',
      image: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9',
      title: 'Moderne Stadtwohnung mit Balkon',
      location: 'Berlin-Mitte',
      price: 1200,
      category: 'apartment'
    },
    {
      id: '2',
      image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c',
      title: 'Penthouse mit Dachterrasse',
      location: 'Berlin-Charlottenburg',
      price: 2500,
      category: 'apartment'
    },
    {
      id: '3',
      image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c',
      title: 'Renovierte Altbauwohnung',
      location: 'Berlin-Prenzlauer Berg',
      price: 1800,
      category: 'apartment'
    },
    {
      id: '4',
      image: 'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3',
      title: 'Loft im Industriestil',
      location: 'Berlin-Friedrichshain',
      price: 1600,
      category: 'apartment'
    }
  ],
  luxury: [
    {
      id: '5',
      image: 'https://images.unsplash.com/photo-1600607687644-c7171b42498f',
      title: 'Luxusvilla mit Pool',
      location: 'Berlin-Grunewald',
      price: 5000,
      category: 'luxury'
    },
    {
      id: '6',
      image: 'https://images.unsplash.com/photo-1600585154526-990dced4db0d',
      title: 'Exklusive Penthouse-Wohnung',
      location: 'Berlin-Mitte',
      price: 4200,
      category: 'luxury'
    },
    {
      id: '7',
      image: 'https://images.unsplash.com/photo-1600573472592-401b489a3cdc',
      title: 'Designer-Apartment',
      location: 'Berlin-Charlottenburg',
      price: 3800,
      category: 'luxury'
    },
    {
      id: '8',
      image: 'https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea',
      title: 'Luxuriöse Maisonette',
      location: 'Berlin-Wilmersdorf',
      price: 4500,
      category: 'luxury'
    }
  ],
  new: [
    {
      id: '9',
      image: 'https://images.unsplash.com/photo-1600566752355-35792bedcfea',
      title: 'Neubau-Erstbezug',
      location: 'Berlin-Mitte',
      price: 2200,
      category: 'new'
    },
    {
      id: '10',
      image: 'https://images.unsplash.com/photo-1600566752584-e88e54d4c6b9',
      title: 'Moderne Neubauwohnung',
      location: 'Berlin-Pankow',
      price: 1900,
      category: 'new'
    },
    {
      id: '11',
      image: 'https://images.unsplash.com/photo-1600566752547-6d0f9a6f6b4e',
      title: 'Neubau mit Garten',
      location: 'Berlin-Lichtenberg',
      price: 2400,
      category: 'new'
    },
    {
      id: '12',
      image: 'https://images.unsplash.com/photo-1600566752355-35792bedcfea',
      title: 'Smart Home Neubau',
      location: 'Berlin-Adlershof',
      price: 2100,
      category: 'new'
    }
  ],
  furnished: [
    {
      id: '13',
      image: 'https://images.unsplash.com/photo-1600566752547-6d0f9a6f6b4e',
      title: 'Möbliertes Studio',
      location: 'Berlin-Mitte',
      price: 1400,
      category: 'furnished'
    },
    {
      id: '14',
      image: 'https://images.unsplash.com/photo-1600566752584-e88e54d4c6b9',
      title: 'Möblierte 2-Zimmer',
      location: 'Berlin-Kreuzberg',
      price: 1600,
      category: 'furnished'
    },
    {
      id: '15',
      image: 'https://images.unsplash.com/photo-1600566752355-35792bedcfea',
      title: 'Business Apartment',
      location: 'Berlin-Mitte',
      price: 1800,
      category: 'furnished'
    },
    {
      id: '16',
      image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c',
      title: 'Serviced Apartment',
      location: 'Berlin-Charlottenburg',
      price: 2000,
      category: 'furnished'
    }
  ],
  commercial: [
    {
      id: '17',
      image: 'https://images.unsplash.com/photo-1600566752355-35792bedcfea',
      title: 'Bürofläche',
      location: 'Berlin-Mitte',
      price: 3500,
      category: 'commercial'
    },
    {
      id: '18',
      image: 'https://images.unsplash.com/photo-1600566752584-e88e54d4c6b9',
      title: 'Ladenlokal',
      location: 'Berlin-Kreuzberg',
      price: 2800,
      category: 'commercial'
    },
    {
      id: '19',
      image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c',
      title: 'Praxisräume',
      location: 'Berlin-Charlottenburg',
      price: 2500,
      category: 'commercial'
    },
    {
      id: '20',
      image: 'https://images.unsplash.com/photo-1600566752547-6d0f9a6f6b4e',
      title: 'Gewerbefläche',
      location: 'Berlin-Wedding',
      price: 3200,
      category: 'commercial'
    }
  ]
};