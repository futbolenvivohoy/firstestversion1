import NodeCache from 'node-cache';

// Initialize cache with 5 minutes standard TTL
const cache = new NodeCache({ stdTTL: 300 });

export const cacheService = {
  get: <T>(key: string): T | undefined => {
    return cache.get(key);
  },

  set: <T>(key: string, value: T, ttl?: number): boolean => {
    return cache.set(key, value, ttl);
  },

  del: (key: string): number => {
    return cache.del(key);
  },

  flush: (): void => {
    cache.flushAll();
  },
};

export const withCache = async <T>(
  key: string,
  fetchFn: () => Promise<T>,
  ttl?: number
): Promise<T> => {
  const cached = cache.get<T>(key);
  if (cached) return cached;

  const fresh = await fetchFn();
  cache.set(key, fresh, ttl);
  return fresh;
};