import sharp from 'sharp';

export const optimizeImage = async (buffer: Buffer, options: {
  width?: number;
  height?: number;
  quality?: number;
}) => {
  const { width, height, quality = 80 } = options;

  return sharp(buffer)
    .resize(width, height, {
      fit: 'cover',
      withoutEnlargement: true,
    })
    .webp({ quality })
    .toBuffer();
};

export const generateThumbnail = async (buffer: Buffer) => {
  return optimizeImage(buffer, {
    width: 300,
    height: 200,
    quality: 70,
  });
};

export const processListingImages = async (images: Buffer[]) => {
  const processed = await Promise.all(
    images.map(async (image) => {
      const [full, thumbnail] = await Promise.all([
        optimizeImage(image, { width: 1200, quality: 85 }),
        generateThumbnail(image),
      ]);

      return {
        full,
        thumbnail,
      };
    })
  );

  return processed;
};