import { Listing } from '../types';

export const generateListingSEO = (listing: Listing) => {
  return {
    title: `${listing.title} | ${listing.city} | RealtyHub`,
    description: truncateDescription(listing.description, 160),
    keywords: generateKeywords(listing),
  };
};

export const generateListingSchema = (listing: Listing) => {
  return {
    '@context': 'https://schema.org',
    '@type': 'RealEstateAgent',
    name: listing.title,
    description: listing.description,
    address: {
      '@type': 'PostalAddress',
      addressLocality: listing.city,
      addressRegion: listing.neighborhood,
      addressCountry: 'DE',
    },
    geo: {
      '@type': 'GeoCoordinates',
      latitude: listing.latitude,
      longitude: listing.longitude,
    },
    priceRange: `${listing.price} €`,
    image: listing.images[0],
    offers: {
      '@type': 'Offer',
      price: listing.price,
      priceCurrency: 'EUR',
      availability: listing.status === 'available' ? 'InStock' : 'OutOfStock',
    },
  };
};

const truncateDescription = (description: string, maxLength: number) => {
  if (description.length <= maxLength) return description;
  return description.substring(0, maxLength - 3) + '...';
};

const generateKeywords = (listing: Listing) => {
  const keywords = [
    listing.category,
    listing.city,
    listing.neighborhood,
    'Immobilien',
    'mieten',
    'vermieten',
  ];

  if (listing.price < 1000) keywords.push('günstig');
  if (listing.status === 'available') keywords.push('sofort verfügbar');

  return keywords.join(', ');
};