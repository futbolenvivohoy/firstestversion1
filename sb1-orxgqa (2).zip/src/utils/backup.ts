import { promises as fs } from 'fs';
import path from 'path';
import { compress } from 'zlib';

interface BackupConfig {
  backupDir: string;
  maxBackups: number;
}

export class BackupService {
  private config: BackupConfig;

  constructor(config: BackupConfig) {
    this.config = config;
  }

  async createBackup(data: any) {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const filename = `backup-${timestamp}.json.gz`;
    const filepath = path.join(this.config.backupDir, filename);

    const jsonData = JSON.stringify(data);
    const compressed = await this.compressData(jsonData);

    await fs.writeFile(filepath, compressed);
    await this.cleanOldBackups();

    return filepath;
  }

  private async compressData(data: string): Promise<Buffer> {
    return new Promise((resolve, reject) => {
      compress(Buffer.from(data), (err, result) => {
        if (err) reject(err);
        else resolve(result);
      });
    });
  }

  private async cleanOldBackups() {
    const files = await fs.readdir(this.config.backupDir);
    const backups = files
      .filter(f => f.startsWith('backup-'))
      .sort()
      .reverse();

    if (backups.length > this.config.maxBackups) {
      const toDelete = backups.slice(this.config.maxBackups);
      await Promise.all(
        toDelete.map(file =>
          fs.unlink(path.join(this.config.backupDir, file))
        )
      );
    }
  }

  async restoreFromBackup(backupPath: string) {
    const compressed = await fs.readFile(backupPath);
    const decompressed = await this.decompressData(compressed);
    return JSON.parse(decompressed.toString());
  }

  private async decompressData(data: Buffer): Promise<Buffer> {
    return new Promise((resolve, reject) => {
      compress(data, (err, result) => {
        if (err) reject(err);
        else resolve(result);
      });
    });
  }
}