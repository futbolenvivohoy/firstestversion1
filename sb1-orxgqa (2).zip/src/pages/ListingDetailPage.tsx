import React from 'react';
import { useParams } from 'react-router-dom';
import { 
  MapPin, 
  Euro, 
  Calendar, 
  Home,
  MessageSquare,
  Phone,
  Share2,
  Heart,
  Flag,
  ChevronLeft,
  ChevronRight,
  Check,
  X
} from 'lucide-react';
import VerificationBadge from '../components/verification/VerificationBadge';
import ListingSEO from '../components/seo/ListingSEO';

const MOCK_LISTING = {
  id: '1',
  title: 'Moderne 3-Zimmer Wohnung mit Balkon',
  description: 'Wunderschöne, helle 3-Zimmer Wohnung in zentraler Lage. Die Wohnung verfügt über einen großzügigen Balkon, eine moderne Einbauküche und wurde kürzlich renoviert.',
  price: 1450,
  category: 'apartment',
  city: 'Berlin',
  neighborhood: 'Mitte',
  images: [
    'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1500&q=80',
    'https://images.unsplash.com/photo-1493809842364-78817add7ffb?auto=format&fit=crop&w=1500&q=80',
    'https://images.unsplash.com/photo-1484154218962-a197022b5858?auto=format&fit=crop&w=1500&q=80'
  ],
  status: 'available',
  features: ['3 Zimmer', '85m²', 'Balkon', 'Einbauküche', 'Aufzug', 'Keller'],
  amenities: ['Parkplatz', 'Waschraum', 'Fahrradraum'],
  availableFrom: '2024-04-01',
  latitude: 52.520008,
  longitude: 13.404954,
  userId: 'user123',
  createdAt: '2024-03-15T12:00:00',
  updatedAt: '2024-03-15T12:00:00'
};

const ListingDetailPage = () => {
  const { id } = useParams();
  const [activeImage, setActiveImage] = React.useState(0);
  const [showContact, setShowContact] = React.useState(false);

  const nextImage = () => {
    setActiveImage((prev) => (prev + 1) % MOCK_LISTING.images.length);
  };

  const prevImage = () => {
    setActiveImage((prev) => 
      prev === 0 ? MOCK_LISTING.images.length - 1 : prev - 1
    );
  };

  return (
    <>
      <ListingSEO listing={MOCK_LISTING} />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Image Gallery */}
        <div className="relative h-[500px] rounded-lg overflow-hidden mb-8">
          <img
            src={MOCK_LISTING.images[activeImage]}
            alt={MOCK_LISTING.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 flex items-center justify-between p-4">
            <button
              onClick={prevImage}
              className="p-2 rounded-full bg-white/80 hover:bg-white shadow-sm"
            >
              <ChevronLeft className="h-6 w-6 text-gray-800" />
            </button>
            <button
              onClick={nextImage}
              className="p-2 rounded-full bg-white/80 hover:bg-white shadow-sm"
            >
              <ChevronRight className="h-6 w-6 text-gray-800" />
            </button>
          </div>
          <div className="absolute bottom-4 right-4 flex space-x-2">
            {MOCK_LISTING.images.map((_, index) => (
              <button
                key={index}
                onClick={() => setActiveImage(index)}
                className={`w-2.5 h-2.5 rounded-full ${
                  index === activeImage ? 'bg-white' : 'bg-white/50'
                }`}
              />
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="flex items-center justify-between mb-4">
                <h1 className="text-2xl font-bold text-gray-900">{MOCK_LISTING.title}</h1>
                <div className="flex items-center space-x-2">
                  <button className="p-2 rounded-full hover:bg-gray-100">
                    <Heart className="h-6 w-6 text-gray-400" />
                  </button>
                  <button className="p-2 rounded-full hover:bg-gray-100">
                    <Share2 className="h-6 w-6 text-gray-400" />
                  </button>
                  <button className="p-2 rounded-full hover:bg-gray-100">
                    <Flag className="h-6 w-6 text-gray-400" />
                  </button>
                </div>
              </div>

              <div className="flex items-center text-gray-500 mb-6">
                <MapPin className="h-5 w-5 mr-2" />
                {MOCK_LISTING.city}, {MOCK_LISTING.neighborhood}
              </div>

              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="flex items-center">
                  <Euro className="h-5 w-5 text-gray-400 mr-2" />
                  <span className="text-xl font-semibold text-gray-900">
                    {MOCK_LISTING.price.toLocaleString()} €
                  </span>
                  <span className="text-gray-500 ml-1">/Monat</span>
                </div>
                <div className="flex items-center">
                  <Calendar className="h-5 w-5 text-gray-400 mr-2" />
                  <span className="text-gray-600">
                    Verfügbar ab {new Date(MOCK_LISTING.availableFrom).toLocaleDateString()}
                  </span>
                </div>
              </div>

              <div className="prose max-w-none mb-8">
                <h2 className="text-lg font-semibold text-gray-900 mb-4">Beschreibung</h2>
                <p className="text-gray-600">{MOCK_LISTING.description}</p>
              </div>

              <div className="mb-8">
                <h2 className="text-lg font-semibold text-gray-900 mb-4">Ausstattung</h2>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {MOCK_LISTING.features.map((feature) => (
                    <div key={feature} className="flex items-center">
                      <Check className="h-5 w-5 text-green-500 mr-2" />
                      <span className="text-gray-600">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="flex items-center mb-6">
                <div className="h-12 w-12 rounded-full bg-gray-200 flex items-center justify-center">
                  <User className="h-6 w-6 text-gray-500" />
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-semibold text-gray-900">Max Mustermann</h3>
                  <VerificationBadge type="private" verified={true} />
                </div>
              </div>

              {showContact ? (
                <div className="space-y-4">
                  <div className="flex items-center">
                    <Phone className="h-5 w-5 text-gray-400 mr-2" />
                    <span className="text-gray-600">+49 123 456789</span>
                  </div>
                  <div className="flex items-center">
                    <MessageSquare className="h-5 w-5 text-gray-400 mr-2" />
                    <span className="text-gray-600">max@example.com</span>
                  </div>
                </div>
              ) : (
                <button
                  onClick={() => setShowContact(true)}
                  className="w-full bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700"
                >
                  Kontakt anzeigen
                </button>
              )}
            </div>

            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Nachricht senden</h3>
              <form className="space-y-4">
                <textarea
                  rows={4}
                  placeholder="Ihre Nachricht..."
                  className="w-full border border-gray-300 rounded-md p-2 focus:ring-indigo-500 focus:border-indigo-500"
                />
                <button
                  type="submit"
                  className="w-full bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700"
                >
                  Nachricht senden
                </button>
              </form>
            </div>
          </div>
        </div>
      </main>
    </>
  );
};

export default ListingDetailPage;