import React, { useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Grid, List, SlidersHorizontal } from 'lucide-react';
import AdvancedSearch from '../components/search/AdvancedSearch';
import ListingCard from '../components/listings/ListingCard';
import ListingListItem from '../components/listings/ListingListItem';

const MOCK_RESULTS = [
  {
    id: '1',
    image: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=800&q=80',
    title: 'Moderne 3-Zimmer Wohnung',
    location: 'Berlin, Mitte',
    price: 1450,
    features: ['3 Zimmer', '85m²', 'Balkon'],
    availableFrom: '2024-04-01',
  },
  {
    id: '2',
    image: 'https://images.unsplash.com/photo-1493809842364-78817add7ffb?auto=format&fit=crop&w=800&q=80',
    title: 'Penthouse mit Dachterrasse',
    location: 'Hamburg, HafenCity',
    price: 2800,
    features: ['4 Zimmer', '120m²', 'Dachterrasse'],
    availableFrom: '2024-05-01',
  },
];

const SearchResultsPage = () => {
  const [searchParams] = useSearchParams();
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [showFilters, setShowFilters] = useState(false);

  const query = searchParams.get('q') || '';
  const category = searchParams.get('category') || '';
  const location = searchParams.get('location') || '';

  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Search Summary */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">
          {query ? `Suchergebnisse für "${query}"` : 'Alle Immobilien'}
        </h1>
        <p className="mt-2 text-sm text-gray-600">
          {MOCK_RESULTS.length} Ergebnisse gefunden
          {category && ` in "${category}"`}
          {location && ` in ${location}`}
        </p>
      </div>

      {/* Controls */}
      <div className="flex items-center justify-between mb-6">
        <button
          onClick={() => setShowFilters(!showFilters)}
          className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
        >
          <SlidersHorizontal className="h-4 w-4 mr-2" />
          Filter
        </button>

        <div className="flex items-center space-x-2">
          <div className="border border-gray-300 rounded-md p-1">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-2 rounded ${
                viewMode === 'grid'
                  ? 'bg-indigo-100 text-indigo-600'
                  : 'text-gray-400 hover:text-gray-500'
              }`}
            >
              <Grid className="h-5 w-5" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-2 rounded ${
                viewMode === 'list'
                  ? 'bg-indigo-100 text-indigo-600'
                  : 'text-gray-400 hover:text-gray-500'
              }`}
            >
              <List className="h-5 w-5" />
            </button>
          </div>

          <select className="border border-gray-300 rounded-md text-sm p-2">
            <option value="newest">Neueste zuerst</option>
            <option value="price_asc">Preis aufsteigend</option>
            <option value="price_desc">Preis absteigend</option>
          </select>
        </div>
      </div>

      {/* Advanced Search Filters */}
      {showFilters && (
        <div className="mb-6">
          <AdvancedSearch />
        </div>
      )}

      {/* Results */}
      {viewMode === 'grid' ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {MOCK_RESULTS.map((listing) => (
            <ListingCard key={listing.id} {...listing} />
          ))}
        </div>
      ) : (
        <div className="space-y-6">
          {MOCK_RESULTS.map((listing) => (
            <ListingListItem key={listing.id} {...listing} />
          ))}
        </div>
      )}
    </main>
  );
};

export default SearchResultsPage;