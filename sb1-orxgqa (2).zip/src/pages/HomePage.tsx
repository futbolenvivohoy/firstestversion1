import React from 'react';
import Sidebar from '../components/Sidebar';
import FeaturedListings from '../components/FeaturedListings';
import NewListings from '../components/NewListings';
import CompanyListings from '../components/CompanyListings';

const HomePage = () => {
  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="flex gap-6 py-6">
        <Sidebar />
        <div className="flex-1 space-y-6">
          <FeaturedListings title="Ausgewählte Immobilien" />
          <FeaturedListings title="Luxus Immobilien" category="luxury" />
          <FeaturedListings title="Neubau Projekte" category="new" />
          <FeaturedListings title="Möblierte Wohnungen" category="furnished" />
          <FeaturedListings title="Gewerbeimmobilien" category="commercial" />
          <NewListings />
          <CompanyListings />
        </div>
      </div>
    </main>
  );
};

export default HomePage;