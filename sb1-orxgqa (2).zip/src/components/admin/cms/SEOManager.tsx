import React from 'react';
import { Globe, Search, Share2 } from 'lucide-react';

const SEOManager = () => {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-xl font-semibold mb-4">SEO Management</h2>
      
      <div className="space-y-6">
        {/* Meta Tags Editor */}
        <div>
          <h3 className="text-lg font-medium mb-2">Meta Tags</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">Title</label>
              <input
                type="text"
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
              />
              <p className="mt-1 text-sm text-gray-500">60 characters remaining</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Description</label>
              <textarea
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                rows={3}
              />
              <p className="mt-1 text-sm text-gray-500">160 characters remaining</p>
            </div>
          </div>
        </div>

        {/* Social Media Preview */}
        <div>
          <h3 className="text-lg font-medium mb-2">Social Media Preview</h3>
          <div className="border rounded-lg p-4">
            <div className="space-y-4">
              <div className="aspect-video bg-gray-100 rounded-lg"></div>
              <div>
                <h4 className="font-medium text-blue-600">Your Page Title</h4>
                <p className="text-sm text-gray-600">Your page description will appear here...</p>
                <p className="text-sm text-gray-500">yourdomain.com</p>
              </div>
            </div>
          </div>
        </div>

        {/* Schema Markup */}
        <div>
          <h3 className="text-lg font-medium mb-2">Schema Markup</h3>
          <select className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
            <option>Article</option>
            <option>Product</option>
            <option>LocalBusiness</option>
            <option>Event</option>
          </select>
        </div>

        {/* Keywords */}
        <div>
          <h3 className="text-lg font-medium mb-2">Keywords</h3>
          <div className="flex flex-wrap gap-2">
            <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-gray-100">
              real estate
              <button className="ml-1 text-gray-500 hover:text-gray-700">×</button>
            </span>
            {/* Add more keywords */}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SEOManager;