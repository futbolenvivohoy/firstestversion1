import React from 'react';
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd';
import { Edit, Trash2, Move } from 'lucide-react';

const ContentBlocks = () => {
  const [blocks, setBlocks] = useState([]);

  const onDragEnd = (result) => {
    // Handle block reordering
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-xl font-semibold mb-4">Content Blocks</h2>
      <DragDropContext onDragEnd={onDragEnd}>
        <Droppable droppableId="content-blocks">
          {(provided) => (
            <div {...provided.droppableProps} ref={provided.innerRef}>
              {blocks.map((block, index) => (
                <Draggable key={block.id} draggableId={block.id} index={index}>
                  {(provided) => (
                    <div
                      ref={provided.innerRef}
                      {...provided.draggableProps}
                      className="bg-gray-50 p-4 mb-2 rounded-md"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <div {...provided.dragHandleProps}>
                            <Move className="h-5 w-5 text-gray-400 mr-2" />
                          </div>
                          <span>{block.title}</span>
                        </div>
                        <div className="flex space-x-2">
                          <button className="p-1 hover:bg-gray-200 rounded">
                            <Edit className="h-4 w-4 text-gray-600" />
                          </button>
                          <button className="p-1 hover:bg-gray-200 rounded">
                            <Trash2 className="h-4 w-4 text-gray-600" />
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </Draggable>
              ))}
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </DragDropContext>
    </div>
  );
};

export default ContentBlocks;