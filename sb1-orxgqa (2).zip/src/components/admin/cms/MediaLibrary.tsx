import React, { useState } from 'react';
import { Upload, Grid, List, Filter } from 'lucide-react';

const MediaLibrary = () => {
  const [view, setView] = useState<'grid' | 'list'>('grid');
  const [selectedFiles, setSelectedFiles] = useState<string[]>([]);

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold">Media Library</h2>
        <div className="flex items-center space-x-4">
          <button className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700">
            <Upload className="h-4 w-4 mr-2" />
            Upload Files
          </button>
          <div className="flex border rounded-md">
            <button
              onClick={() => setView('grid')}
              className={`p-2 ${view === 'grid' ? 'bg-gray-100' : ''}`}
            >
              <Grid className="h-4 w-4" />
            </button>
            <button
              onClick={() => setView('list')}
              className={`p-2 ${view === 'list' ? 'bg-gray-100' : ''}`}
            >
              <List className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      <div className="flex gap-6">
        {/* Filters */}
        <div className="w-64 flex-shrink-0">
          <div className="space-y-4">
            <div>
              <h3 className="text-sm font-medium text-gray-700">File Type</h3>
              <div className="mt-2 space-y-2">
                <label className="flex items-center">
                  <input type="checkbox" className="rounded text-indigo-600" />
                  <span className="ml-2 text-sm text-gray-600">Images</span>
                </label>
                <label className="flex items-center">
                  <input type="checkbox" className="rounded text-indigo-600" />
                  <span className="ml-2 text-sm text-gray-600">Documents</span>
                </label>
                <label className="flex items-center">
                  <input type="checkbox" className="rounded text-indigo-600" />
                  <span className="ml-2 text-sm text-gray-600">Videos</span>
                </label>
              </div>
            </div>

            <div>
              <h3 className="text-sm font-medium text-gray-700">Date Added</h3>
              <select className="mt-2 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                <option>Last 7 days</option>
                <option>Last 30 days</option>
                <option>Last 3 months</option>
                <option>All time</option>
              </select>
            </div>
          </div>
        </div>

        {/* Media Grid/List */}
        <div className="flex-1">
          {view === 'grid' ? (
            <div className="grid grid-cols-4 gap-4">
              {/* Media Items */}
              {Array.from({ length: 12 }).map((_, i) => (
                <div
                  key={i}
                  className={`aspect-square bg-gray-100 rounded-lg cursor-pointer ${
                    selectedFiles.includes(String(i)) ? 'ring-2 ring-indigo-500' : ''
                  }`}
                  onClick={() => {
                    if (selectedFiles.includes(String(i))) {
                      setSelectedFiles(selectedFiles.filter(id => id !== String(i)));
                    } else {
                      setSelectedFiles([...selectedFiles, String(i)]);
                    }
                  }}
                />
              ))}
            </div>
          ) : (
            <div className="space-y-2">
              {/* List View */}
              {Array.from({ length: 12 }).map((_, i) => (
                <div
                  key={i}
                  className={`flex items-center p-3 rounded-lg hover:bg-gray-50 ${
                    selectedFiles.includes(String(i)) ? 'bg-indigo-50' : ''
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={selectedFiles.includes(String(i))}
                    onChange={(e) => {
                      if (e.target.checked) {
                        setSelectedFiles([...selectedFiles, String(i)]);
                      } else {
                        setSelectedFiles(selectedFiles.filter(id => id !== String(i)));
                      }
                    }}
                    className="h-4 w-4 text-indigo-600 rounded"
                  />
                  <div className="ml-4 flex-1">
                    <p className="text-sm font-medium text-gray-900">image-{i + 1}.jpg</p>
                    <p className="text-sm text-gray-500">Added on Mar 16, 2024</p>
                  </div>
                  <p className="text-sm text-gray-500">2.4 MB</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default MediaLibrary;