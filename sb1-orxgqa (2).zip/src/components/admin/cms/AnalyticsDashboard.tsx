import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { TrendingUp, Users, Eye, Clock } from 'lucide-react';

const AnalyticsDashboard = () => {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-xl font-semibold mb-6">Analytics Overview</h2>

      <div className="grid grid-cols-4 gap-6 mb-8">
        <div className="bg-gray-50 p-4 rounded-lg">
          <div className="flex items-center">
            <Users className="h-6 w-6 text-indigo-600" />
            <div className="ml-3">
              <p className="text-sm font-medium text-gray-600">Total Users</p>
              <p className="text-2xl font-semibold text-gray-900">2,543</p>
            </div>
          </div>
          <div className="mt-2 flex items-center text-sm text-green-600">
            <TrendingUp className="h-4 w-4 mr-1" />
            <span>12% increase</span>
          </div>
        </div>

        <div className="bg-gray-50 p-4 rounded-lg">
          <div className="flex items-center">
            <Eye className="h-6 w-6 text-indigo-600" />
            <div className="ml-3">
              <p className="text-sm font-medium text-gray-600">Page Views</p>
              <p className="text-2xl font-semibold text-gray-900">18,249</p>
            </div>
          </div>
          <div className="mt-2 flex items-center text-sm text-green-600">
            <TrendingUp className="h-4 w-4 mr-1" />
            <span>8% increase</span>
          </div>
        </div>

        {/* Add more stats */}
      </div>

      <div className="space-y-6">
        {/* Traffic Chart */}
        <div>
          <h3 className="text-lg font-medium mb-4">Traffic Overview</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={[/* Your data */]}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="value" fill="#4F46E5" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Popular Pages */}
        <div>
          <h3 className="text-lg font-medium mb-4">Popular Pages</h3>
          <div className="space-y-4">
            {/* Page items */}
            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center">
                <div className="w-12 h-12 bg-gray-200 rounded"></div>
                <div className="ml-4">
                  <p className="font-medium text-gray-900">Homepage</p>
                  <p className="text-sm text-gray-500">/</p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-medium text-gray-900">5,123</p>
                <p className="text-sm text-gray-500">views</p>
              </div>
            </div>
            {/* Add more pages */}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnalyticsDashboard;