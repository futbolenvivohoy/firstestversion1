import React from 'react';
import { GripVertical, Pencil, Trash2, Plus } from 'lucide-react';

const MOCK_CATEGORIES = [
  {
    id: '1',
    name: 'Wohnungen',
    slug: 'wohnungen',
    listingCount: 234,
    order: 1,
  },
  {
    id: '2',
    name: 'Häuser',
    slug: 'haeuser',
    listingCount: 156,
    order: 2,
  },
  {
    id: '3',
    name: 'Gewerbe',
    slug: 'gewerbe',
    listingCount: 45,
    order: 3,
  },
];

const CategoryManagement = () => {
  return (
    <div className="p-6">
      <div className="sm:flex sm:items-center">
        <div className="sm:flex-auto">
          <h2 className="text-xl font-semibold text-gray-900">Kategorieverwaltung</h2>
          <p className="mt-2 text-sm text-gray-700">
            Verwalten und organisieren Sie die Immobilienkategorien.
          </p>
        </div>
        <div className="mt-4 sm:mt-0 sm:ml-16 sm:flex-none">
          <button className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700">
            <Plus className="h-4 w-4 mr-2" />
            Neue Kategorie
          </button>
        </div>
      </div>

      <div className="mt-8 flow-root">
        <ul className="divide-y divide-gray-200">
          {MOCK_CATEGORIES.map((category) => (
            <li
              key={category.id}
              className="py-4 flex items-center justify-between hover:bg-gray-50"
            >
              <div className="flex items-center">
                <button className="cursor-move p-2 hover:bg-gray-100 rounded">
                  <GripVertical className="h-5 w-5 text-gray-400" />
                </button>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-900">{category.name}</p>
                  <p className="text-sm text-gray-500">/{category.slug}</p>
                </div>
                <div className="ml-4">
                  <span className="inline-flex items-center rounded-full bg-gray-100 px-2.5 py-0.5 text-xs font-medium text-gray-800">
                    {category.listingCount} Anzeigen
                  </span>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <button className="p-2 text-gray-400 hover:text-gray-500">
                  <Pencil className="h-5 w-5" />
                </button>
                <button className="p-2 text-gray-400 hover:text-red-500">
                  <Trash2 className="h-5 w-5" />
                </button>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default CategoryManagement;