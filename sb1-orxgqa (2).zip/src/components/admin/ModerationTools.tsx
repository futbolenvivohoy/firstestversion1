import React from 'react';
import { AlertTriangle, MessageSquare, Flag, Shield, Home } from 'lucide-react';

const MOCK_REPORTS = [
  {
    id: '1',
    type: 'listing',
    title: 'Verdächtige Anzeige',
    content: 'Moderne 3-Zimmer Wohnung',
    reporter: 'Max Mustermann',
    reason: 'Verdacht auf Betrug',
    date: '2024-03-16T14:30:00',
    status: 'pending',
  },
  {
    id: '2',
    type: 'message',
    title: 'Unangemessene Nachricht',
    content: 'Penthouse mit Dachterrasse',
    reporter: 'Anna Schmidt',
    reason: 'Belästigung',
    date: '2024-03-16T12:15:00',
    status: 'pending',
  },
];

const ModerationTools = () => {
  return (
    <div className="p-6">
      <div className="sm:flex sm:items-center">
        <div className="sm:flex-auto">
          <h2 className="text-xl font-semibold text-gray-900">Moderation</h2>
          <p className="mt-2 text-sm text-gray-700">
            Überprüfen und moderieren Sie gemeldete Inhalte.
          </p>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <AlertTriangle className="h-6 w-6 text-yellow-400" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Offene Meldungen
                  </dt>
                  <dd className="flex items-baseline">
                    <div className="text-2xl font-semibold text-gray-900">12</div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Shield className="h-6 w-6 text-green-400" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Bearbeitete Meldungen
                  </dt>
                  <dd className="flex items-baseline">
                    <div className="text-2xl font-semibold text-gray-900">48</div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Flag className="h-6 w-6 text-red-400" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Kritische Fälle
                  </dt>
                  <dd className="flex items-baseline">
                    <div className="text-2xl font-semibold text-gray-900">3</div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Reports List */}
      <div className="mt-8">
        <div className="overflow-hidden shadow ring-1 ring-black ring-opacity-5 sm:rounded-lg">
          <table className="min-w-full divide-y divide-gray-300">
            <thead className="bg-gray-50">
              <tr>
                <th className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900">
                  Meldung
                </th>
                <th className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                  Typ
                </th>
                <th className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                  Grund
                </th>
                <th className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                  Gemeldet von
                </th>
                <th className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                  Datum
                </th>
                <th className="relative py-3.5 pl-3 pr-4 sm:pr-6">
                  <span className="sr-only">Aktionen</span>
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 bg-white">
              {MOCK_REPORTS.map((report) => (
                <tr key={report.id}>
                  <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm">
                    <div className="font-medium text-gray-900">{report.title}</div>
                    <div className="text-gray-500">{report.content}</div>
                  </td>
                  <td className="whitespace-nowrap px-3 py-4 text-sm">
                    <span className="inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium capitalize">
                      {report.type === 'listing' ? (
                        <>
                          <Home className="mr-1 h-4 w-4 text-gray-500" />
                          Anzeige
                        </>
                      ) : (
                        <>
                          <MessageSquare className="mr-1 h-4 w-4 text-gray-500" />
                          Nachricht
                        </>
                      )}
                    </span>
                  </td>
                  <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                    {report.reason}
                  </td>
                  <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                    {report.reporter}
                  </td>
                  <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                    {new Date(report.date).toLocaleString()}
                  </td>
                  <td className="relative whitespace-nowrap py-4 pl-3 pr-4 text-right text-sm font-medium sm:pr-6">
                    <div className="flex justify-end space-x-2">
                      <button className="text-indigo-600 hover:text-indigo-900">
                        Details
                      </button>
                      <button className="text-green-600 hover:text-green-900">
                        Genehmigen
                      </button>
                      <button className="text-red-600 hover:text-red-900">
                        Ablehnen
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* AI Moderation Settings */}
      <div className="mt-8">
        <h3 className="text-lg font-medium text-gray-900 mb-4">KI-Moderationseinstellungen</h3>
        <div className="bg-white shadow sm:rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            <div className="space-y-6">
              <div>
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                    defaultChecked
                  />
                  <span className="ml-2 text-sm text-gray-900">
                    Automatische Erkennung von anstößigen Inhalten
                  </span>
                </label>
              </div>
              <div>
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                    defaultChecked
                  />
                  <span className="ml-2 text-sm text-gray-900">
                    Spam-Erkennung für Nachrichten
                  </span>
                </label>
              </div>
              <div>
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                    defaultChecked
                  />
                  <span className="ml-2 text-sm text-gray-900">
                    Automatische Blockierung verdächtiger Benutzer
                  </span>
                </label>
              </div>
            </div>
            <div className="mt-6">
              <button className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700">
                Einstellungen speichern
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ModerationTools;