import React from 'react';
import { Check, X, Eye, Flag } from 'lucide-react';

const MOCK_LISTINGS = [
  {
    id: '1',
    title: 'Moderne 3-Zimmer Wohnung',
    user: 'Max Mustermann',
    userType: 'private',
    price: '1.250 €',
    location: 'Berlin, Mitte',
    submitted: '2024-03-16T14:30:00',
    status: 'pending',
    flags: 2,
  },
  {
    id: '2',
    title: 'Penthouse mit Dachterrasse',
    user: 'Immobilien Schmidt GmbH',
    userType: 'agency',
    price: '2.800 €',
    location: 'Hamburg, HafenCity',
    submitted: '2024-03-16T12:15:00',
    status: 'pending',
    flags: 0,
  },
];

const ListingApproval = () => {
  return (
    <div className="p-6">
      <div className="sm:flex sm:items-center">
        <div className="sm:flex-auto">
          <h2 className="text-xl font-semibold text-gray-900">Anzeigenprüfung</h2>
          <p className="mt-2 text-sm text-gray-700">
            Prüfen und genehmigen Sie neue Immobilienanzeigen.
          </p>
        </div>
      </div>

      <div className="mt-8 flow-root">
        <div className="-mx-4 -my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
          <div className="inline-block min-w-full py-2 align-middle sm:px-6 lg:px-8">
            <table className="min-w-full divide-y divide-gray-300">
              <thead>
                <tr>
                  <th className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900">
                    Anzeige
                  </th>
                  <th className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                    Inserent
                  </th>
                  <th className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                    Preis
                  </th>
                  <th className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                    Standort
                  </th>
                  <th className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                    Eingereicht
                  </th>
                  <th className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                    Meldungen
                  </th>
                  <th className="relative py-3.5 pl-3 pr-4">
                    <span className="sr-only">Aktionen</span>
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {MOCK_LISTINGS.map((listing) => (
                  <tr key={listing.id}>
                    <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm">
                      <div className="font-medium text-gray-900">{listing.title}</div>
                      <div className="text-gray-500">{listing.id}</div>
                    </td>
                    <td className="whitespace-nowrap px-3 py-4 text-sm">
                      <div className="text-gray-900">{listing.user}</div>
                      <div className="text-gray-500">
                        {listing.userType === 'agency' ? 'Gewerbe' : 'Privat'}
                      </div>
                    </td>
                    <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                      {listing.price}
                    </td>
                    <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                      {listing.location}
                    </td>
                    <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                      {new Date(listing.submitted).toLocaleString()}
                    </td>
                    <td className="whitespace-nowrap px-3 py-4 text-sm">
                      {listing.flags > 0 ? (
                        <span className="inline-flex items-center rounded-full bg-red-100 px-2.5 py-0.5 text-xs font-medium text-red-800">
                          <Flag className="h-3 w-3 mr-1" />
                          {listing.flags}
                        </span>
                      ) : (
                        <span className="text-gray-500">-</span>
                      )}
                    </td>
                    <td className="relative whitespace-nowrap py-4 pl-3 pr-4 text-right text-sm font-medium">
                      <div className="flex justify-end space-x-2">
                        <button className="text-indigo-600 hover:text-indigo-900">
                          <Eye className="h-5 w-5" />
                        </button>
                        <button className="text-green-600 hover:text-green-900">
                          <Check className="h-5 w-5" />
                        </button>
                        <button className="text-red-600 hover:text-red-900">
                          <X className="h-5 w-5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ListingApproval;