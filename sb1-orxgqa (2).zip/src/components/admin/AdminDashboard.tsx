import React from 'react';
import { Users, Home, Tag, BarChart2, Bell, Shield } from 'lucide-react';
import UserManagement from './UserManagement';
import ListingApproval from './ListingApproval';
import CategoryManagement from './CategoryManagement';
import AdminAnalytics from './AdminAnalytics';
import ModerationTools from './ModerationTools';

const AdminDashboard = () => {
  const [activeTab, setActiveTab] = React.useState('users');

  const tabs = [
    { id: 'users', name: 'Benutzer', icon: Users },
    { id: 'listings', name: 'Anzeigen', icon: Home },
    { id: 'categories', name: 'Kategorien', icon: Tag },
    { id: 'analytics', name: 'Analysen', icon: BarChart2 },
    { id: 'moderation', name: 'Moderation', icon: Shield },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <div className="flex items-center">
              <Users className="h-8 w-8 text-indigo-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Aktive Nutzer</p>
                <p className="text-2xl font-semibold text-gray-900">2,451</p>
              </div>
            </div>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <div className="flex items-center">
              <Home className="h-8 w-8 text-indigo-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Offene Anzeigen</p>
                <p className="text-2xl font-semibold text-gray-900">48</p>
              </div>
            </div>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <div className="flex items-center">
              <Bell className="h-8 w-8 text-indigo-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Meldungen</p>
                <p className="text-2xl font-semibold text-gray-900">12</p>
              </div>
            </div>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <div className="flex items-center">
              <BarChart2 className="h-8 w-8 text-indigo-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Seitenaufrufe</p>
                <p className="text-2xl font-semibold text-gray-900">15.2k</p>
              </div>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="border-b border-gray-200 mb-8">
          <nav className="-mb-px flex space-x-8">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`
                  group inline-flex items-center py-4 px-1 border-b-2 font-medium text-sm
                  ${
                    activeTab === tab.id
                      ? 'border-indigo-500 text-indigo-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }
                `}
              >
                <tab.icon
                  className={`
                    -ml-0.5 mr-2 h-5 w-5
                    ${
                      activeTab === tab.id
                        ? 'text-indigo-500'
                        : 'text-gray-400 group-hover:text-gray-500'
                    }
                  `}
                />
                {tab.name}
              </button>
            ))}
          </nav>
        </div>

        {/* Content Area */}
        <div className="bg-white rounded-lg shadow-sm">
          {activeTab === 'users' && <UserManagement />}
          {activeTab === 'listings' && <ListingApproval />}
          {activeTab === 'categories' && <CategoryManagement />}
          {activeTab === 'analytics' && <AdminAnalytics />}
          {activeTab === 'moderation' && <ModerationTools />}
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;