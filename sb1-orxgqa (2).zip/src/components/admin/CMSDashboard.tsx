import React from 'react';
import { Layout, Grid, Stats, QuickActions } from './cms/layout';
import { useAdminStore } from '../../store/useAdminStore';

const CMSDashboard = () => {
  const stats = useAdminStore(state => state.stats);

  return (
    <Layout>
      <QuickActions />
      <Stats data={stats} />
      <Grid>
        {/* Content Blocks */}
        <ContentBlocks />
        {/* SEO Management */}
        <SEOManager />
        {/* Media Library */}
        <MediaLibrary />
        {/* Analytics */}
        <AnalyticsDashboard />
      </Grid>
    </Layout>
  );
};

export default CMSDashboard;