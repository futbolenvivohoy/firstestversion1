import React from 'react';
import { Building2, ExternalLink } from 'lucide-react';

const COMPANIES = [
  {
    id: 1,
    name: 'Immobilien Schmidt GmbH',
    logo: 'https://images.unsplash.com/photo-1560179707-f14e90ef3623?auto=format&fit=crop&w=300&q=80',
    location: 'Berlin',
    listingCount: 45,
  },
  {
    id: 2,
    name: 'Meyer & Partner',
    logo: 'https://images.unsplash.com/photo-1622547748225-3fc4abd2cca0?auto=format&fit=crop&w=300&q=80',
    location: 'Hamburg',
    listingCount: 32,
  },
  {
    id: 3,
    name: 'Immobilien Müller',
    logo: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=300&q=80',
    location: 'München',
    listingCount: 28,
  },
  {
    id: 4,
    name: 'Wagner Immobilien',
    logo: 'https://images.unsplash.com/photo-1497366811353-6870744d04b2?auto=format&fit=crop&w=300&q=80',
    location: 'Frankfurt',
    listingCount: 23,
  },
];

const CompanyListings = () => {
  return (
    <section className="bg-white rounded-lg shadow-sm">
      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold text-gray-900">Unternehmensseiten</h2>
          <a href="#" className="text-sm font-medium text-indigo-600 hover:text-indigo-500 inline-flex items-center">
            Alle anzeigen
            <ExternalLink className="ml-1 h-4 w-4" />
          </a>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {COMPANIES.map((company) => (
            <div key={company.id} className="relative group">
              <div className="aspect-w-16 aspect-h-9 rounded-lg bg-gray-100 overflow-hidden">
                <img
                  src={company.logo}
                  alt={company.name}
                  className="object-cover"
                />
              </div>
              <div className="mt-4">
                <h3 className="text-lg font-semibold text-gray-900">{company.name}</h3>
                <div className="mt-1 flex items-center text-sm text-gray-500">
                  <Building2 className="h-4 w-4 mr-1" />
                  <span>{company.location}</span>
                </div>
                <p className="mt-1 text-sm text-indigo-600">
                  {company.listingCount} Immobilien
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CompanyListings;