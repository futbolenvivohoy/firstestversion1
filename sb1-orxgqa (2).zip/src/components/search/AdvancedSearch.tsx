import React, { useState } from 'react';
import { Search, Sliders, MapPin, Euro, Home, Calendar } from 'lucide-react';

interface SearchFilters {
  category: string;
  priceMin: string;
  priceMax: string;
  location: string;
  furnished: boolean;
  petFriendly: boolean;
  availableFrom: string;
  sortBy: string;
}

const AdvancedSearch = () => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [filters, setFilters] = useState<SearchFilters>({
    category: '',
    priceMin: '',
    priceMax: '',
    location: '',
    furnished: false,
    petFriendly: false,
    availableFrom: '',
    sortBy: 'newest'
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle search logic
  };

  return (
    <div className="bg-white rounded-lg shadow-sm">
      <div className="p-6">
        <form onSubmit={handleSearch}>
          {/* Main Search Bar */}
          <div className="flex items-center gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                placeholder="Suchbegriff eingeben..."
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>
            <button
              type="button"
              onClick={() => setIsExpanded(!isExpanded)}
              className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md text-gray-700 bg-white hover:bg-gray-50"
            >
              <Sliders className="h-5 w-5 mr-2" />
              Filter
            </button>
            <button
              type="submit"
              className="px-6 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
            >
              Suchen
            </button>
          </div>

          {/* Advanced Filters */}
          {isExpanded && (
            <div className="mt-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Kategorie
                </label>
                <div className="relative">
                  <select
                    value={filters.category}
                    onChange={(e) => setFilters({ ...filters, category: e.target.value })}
                    className="block w-full pl-3 pr-10 py-2 text-base border border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 rounded-md"
                  >
                    <option value="">Alle Kategorien</option>
                    <option value="apartment">Wohnungen</option>
                    <option value="house">Häuser</option>
                    <option value="commercial">Gewerbe</option>
                  </select>
                  <Home className="absolute right-3 top-2.5 h-5 w-5 text-gray-400" />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Preisspanne
                </label>
                <div className="flex items-center gap-2">
                  <div className="relative flex-1">
                    <input
                      type="number"
                      placeholder="Min"
                      value={filters.priceMin}
                      onChange={(e) => setFilters({ ...filters, priceMin: e.target.value })}
                      className="block w-full pl-7 pr-3 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                    />
                    <span className="absolute left-2 top-2 text-gray-500">€</span>
                  </div>
                  <span className="text-gray-500">-</span>
                  <div className="relative flex-1">
                    <input
                      type="number"
                      placeholder="Max"
                      value={filters.priceMax}
                      onChange={(e) => setFilters({ ...filters, priceMax: e.target.value })}
                      className="block w-full pl-7 pr-3 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                    />
                    <span className="absolute left-2 top-2 text-gray-500">€</span>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Standort
                </label>
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Stadt oder PLZ"
                    value={filters.location}
                    onChange={(e) => setFilters({ ...filters, location: e.target.value })}
                    className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                  />
                  <MapPin className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Verfügbar ab
                </label>
                <div className="relative">
                  <input
                    type="date"
                    value={filters.availableFrom}
                    onChange={(e) => setFilters({ ...filters, availableFrom: e.target.value })}
                    className="block w-full pl-3 pr-10 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                  />
                  <Calendar className="absolute right-3 top-2.5 h-5 w-5 text-gray-400" />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Sortierung
                </label>
                <select
                  value={filters.sortBy}
                  onChange={(e) => setFilters({ ...filters, sortBy: e.target.value })}
                  className="block w-full pl-3 pr-10 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                >
                  <option value="newest">Neueste zuerst</option>
                  <option value="price_asc">Preis aufsteigend</option>
                  <option value="price_desc">Preis absteigend</option>
                  <option value="relevance">Relevanz</option>
                </select>
              </div>

              <div className="space-y-4">
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={filters.furnished}
                    onChange={(e) => setFilters({ ...filters, furnished: e.target.checked })}
                    className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                  />
                  <span className="ml-2 text-sm text-gray-700">Möbliert</span>
                </label>
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={filters.petFriendly}
                    onChange={(e) => setFilters({ ...filters, petFriendly: e.target.checked })}
                    className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                  />
                  <span className="ml-2 text-sm text-gray-700">Haustiere erlaubt</span>
                </label>
              </div>
            </div>
          )}
        </form>
      </div>
    </div>
  );
};

export default AdvancedSearch;