import React from 'react';
import { MapPin, Home, Euro } from 'lucide-react';

const SearchFilters = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-white rounded-lg shadow-sm">
      <div className="relative">
        <label className="block text-sm font-medium text-gray-700 mb-1">Kategorie</label>
        <select className="w-full pl-3 pr-10 py-2 text-base border border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 rounded-md">
          <option value="">Alle Kategorien</option>
          <option value="apartment">Wohnungen</option>
          <option value="house">Häuser</option>
          <option value="room">Zimmer</option>
          <option value="commercial">Gewerbe</option>
        </select>
        <Home className="absolute right-3 top-9 h-5 w-5 text-gray-400" />
      </div>

      <div className="relative">
        <label className="block text-sm font-medium text-gray-700 mb-1">Stadt</label>
        <select className="w-full pl-3 pr-10 py-2 text-base border border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 rounded-md">
          <option value="">Alle Städte</option>
          <option value="berlin">Berlin</option>
          <option value="hamburg">Hamburg</option>
          <option value="munich">München</option>
          <option value="cologne">Köln</option>
        </select>
        <MapPin className="absolute right-3 top-9 h-5 w-5 text-gray-400" />
      </div>

      <div className="relative">
        <label className="block text-sm font-medium text-gray-700 mb-1">Preis bis</label>
        <select className="w-full pl-3 pr-10 py-2 text-base border border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 rounded-md">
          <option value="">Beliebig</option>
          <option value="500">500 €</option>
          <option value="1000">1.000 €</option>
          <option value="1500">1.500 €</option>
          <option value="2000">2.000 €</option>
          <option value="2500">2.500 €</option>
        </select>
        <Euro className="absolute right-3 top-9 h-5 w-5 text-gray-400" />
      </div>
    </div>
  );
};

export default SearchFilters;