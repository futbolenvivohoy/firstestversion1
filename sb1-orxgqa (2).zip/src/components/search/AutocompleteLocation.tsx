import React, { useState, useEffect, useRef } from 'react';
import { MapPin } from 'lucide-react';

interface Location {
  id: string;
  city: string;
  district?: string;
  type: 'city' | 'district';
}

const MOCK_LOCATIONS: Location[] = [
  { id: '1', city: 'Berlin', type: 'city' },
  { id: '2', city: 'Berlin', district: 'Mitte', type: 'district' },
  { id: '3', city: 'Berlin', district: 'Kreuzberg', type: 'district' },
  { id: '4', city: 'Hamburg', type: 'city' },
  { id: '5', city: 'Hamburg', district: 'St. Pauli', type: 'district' },
  { id: '6', city: 'München', type: 'city' },
  { id: '7', city: 'München', district: 'Schwabing', type: 'district' },
];

const AutocompleteLocation = () => {
  const [query, setQuery] = useState('');
  const [suggestions, setSuggestions] = useState<Location[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const wrapperRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    if (query.length >= 2) {
      const filtered = MOCK_LOCATIONS.filter(
        location =>
          location.city.toLowerCase().includes(query.toLowerCase()) ||
          location.district?.toLowerCase().includes(query.toLowerCase())
      );
      setSuggestions(filtered);
      setIsOpen(true);
    } else {
      setSuggestions([]);
      setIsOpen(false);
    }
  }, [query]);

  const handleSelect = (location: Location) => {
    setQuery(location.district 
      ? `${location.city}, ${location.district}`
      : location.city
    );
    setIsOpen(false);
  };

  return (
    <div ref={wrapperRef} className="relative">
      <div className="relative">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => query.length >= 2 && setIsOpen(true)}
          placeholder="Ort oder PLZ"
          className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
        />
        <MapPin className="absolute left-3 top-3.5 h-5 w-5 text-gray-400" />
      </div>

      {isOpen && suggestions.length > 0 && (
        <div className="absolute z-50 w-full mt-1 bg-white rounded-lg shadow-lg border border-gray-200 max-h-60 overflow-auto">
          <div className="py-2">
            {suggestions.map((location) => (
              <button
                key={`${location.id}-${location.district || 'city'}`}
                type="button"
                onClick={() => handleSelect(location)}
                className="w-full px-4 py-2 text-left hover:bg-gray-50"
              >
                <div className="flex items-center">
                  <MapPin className="h-4 w-4 text-gray-400 mr-2" />
                  <div>
                    <span className="font-medium">{location.city}</span>
                    {location.district && (
                      <span className="text-gray-500">, {location.district}</span>
                    )}
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default AutocompleteLocation;