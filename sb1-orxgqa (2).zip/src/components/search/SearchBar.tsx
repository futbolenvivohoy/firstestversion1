import React from 'react';
import { Search, MapPin, Euro, Home } from 'lucide-react';

const SearchBar = () => {
  return (
    <div className="bg-white/80 backdrop-blur-sm rounded-lg shadow-sm p-2 max-w-4xl mx-auto">
      <div className="flex items-center gap-2">
        {/* Search Input */}
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <input
            type="text"
            placeholder="Ort oder Postleitzahl eingeben"
            className="w-full pl-9 pr-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
          />
        </div>

        {/* Category Dropdown */}
        <div className="w-44">
          <select className="w-full pl-3 pr-3 py-2 text-sm border border-gray-300 rounded-lg appearance-none bg-white focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
            <option value="">Alle Kategorien</option>
            <option value="apartment">Wohnungen</option>
            <option value="house">Häuser</option>
            <option value="commercial">Gewerbe</option>
          </select>
        </div>

        {/* Price Range */}
        <div className="w-44">
          <select className="w-full pl-3 pr-3 py-2 text-sm border border-gray-300 rounded-lg appearance-none bg-white focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
            <option value="">Preis bis</option>
            <option value="500">500 €</option>
            <option value="1000">1.000 €</option>
            <option value="1500">1.500 €</option>
            <option value="2000">2.000 €</option>
          </select>
        </div>

        {/* Search Button */}
        <button className="px-6 py-2 text-sm bg-indigo-600 text-white font-medium rounded-lg hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors">
          Finden
        </button>
      </div>
    </div>
  );
};

export default SearchBar;