import React, { useState } from 'react';
import { Star, ThumbsUp, Flag, MessageSquare } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

interface Review {
  id: string;
  userId: string;
  listingId: string;
  rating: number;
  content: string;
  createdAt: string;
  helpful: number;
  verified: boolean;
  response?: {
    content: string;
    createdAt: string;
  };
}

interface ReviewSystemProps {
  listingId: string;
  reviews: Review[];
  onSubmitReview: (review: Omit<Review, 'id' | 'createdAt' | 'helpful' | 'verified'>) => void;
  onMarkHelpful: (reviewId: string) => void;
  onReportReview: (reviewId: string, reason: string) => void;
}

const ReviewSystem: React.FC<ReviewSystemProps> = ({
  listingId,
  reviews,
  onSubmitReview,
  onMarkHelpful,
  onReportReview,
}) => {
  const { user, isAuthenticated } = useAuth();
  const [rating, setRating] = useState(0);
  const [content, setContent] = useState('');
  const [showReportModal, setShowReportModal] = useState(false);
  const [selectedReview, setSelectedReview] = useState<string | null>(null);
  const [reportReason, setReportReason] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAuthenticated || !user) return;

    onSubmitReview({
      userId: user.id,
      listingId,
      rating,
      content,
    });

    setRating(0);
    setContent('');
  };

  const handleReport = () => {
    if (selectedReview) {
      onReportReview(selectedReview, reportReason);
      setShowReportModal(false);
      setSelectedReview(null);
      setReportReason('');
    }
  };

  return (
    <div className="space-y-8">
      {/* Review Form */}
      {isAuthenticated && (
        <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-sm p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Bewertung schreiben</h3>
          
          <div className="mb-4">
            <div className="flex items-center space-x-1">
              {[1, 2, 3, 4, 5].map((value) => (
                <button
                  key={value}
                  type="button"
                  onClick={() => setRating(value)}
                  className="p-1 focus:outline-none"
                >
                  <Star
                    className={`h-6 w-6 ${
                      value <= rating ? 'text-yellow-400 fill-current' : 'text-gray-300'
                    }`}
                  />
                </button>
              ))}
            </div>
          </div>

          <div className="mb-4">
            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              rows={4}
              className="w-full border border-gray-300 rounded-md p-2 focus:ring-indigo-500 focus:border-indigo-500"
              placeholder="Ihre Erfahrung..."
              required
            />
          </div>

          <button
            type="submit"
            className="w-full bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700"
          >
            Bewertung absenden
          </button>
        </form>
      )}

      {/* Reviews List */}
      <div className="space-y-6">
        {reviews.map((review) => (
          <div key={review.id} className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="flex items-center">
                  {[1, 2, 3, 4, 5].map((value) => (
                    <Star
                      key={value}
                      className={`h-5 w-5 ${
                        value <= review.rating ? 'text-yellow-400 fill-current' : 'text-gray-300'
                      }`}
                    />
                  ))}
                </div>
                {review.verified && (
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                    Verifizierter Kauf
                  </span>
                )}
              </div>
              <span className="text-sm text-gray-500">
                {new Date(review.createdAt).toLocaleDateString()}
              </span>
            </div>

            <p className="mt-4 text-gray-700">{review.content}</p>

            {review.response && (
              <div className="mt-4 pl-4 border-l-4 border-gray-200">
                <p className="text-sm font-medium text-gray-900">Antwort vom Vermieter:</p>
                <p className="mt-1 text-sm text-gray-700">{review.response.content}</p>
                <p className="mt-1 text-xs text-gray-500">
                  {new Date(review.response.createdAt).toLocaleDateString()}
                </p>
              </div>
            )}

            <div className="mt-4 flex items-center space-x-4">
              <button
                onClick={() => onMarkHelpful(review.id)}
                className="flex items-center text-sm text-gray-500 hover:text-gray-700"
              >
                <ThumbsUp className="h-4 w-4 mr-1" />
                Hilfreich ({review.helpful})
              </button>
              <button
                onClick={() => {
                  setSelectedReview(review.id);
                  setShowReportModal(true);
                }}
                className="flex items-center text-sm text-gray-500 hover:text-gray-700"
              >
                <Flag className="h-4 w-4 mr-1" />
                Melden
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Report Modal */}
      {showReportModal && (
        <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Bewertung melden</h3>
            <textarea
              value={reportReason}
              onChange={(e) => setReportReason(e.target.value)}
              rows={4}
              className="w-full border border-gray-300 rounded-md p-2 mb-4"
              placeholder="Grund für die Meldung..."
              required
            />
            <div className="flex justify-end space-x-4">
              <button
                onClick={() => setShowReportModal(false)}
                className="px-4 py-2 text-sm font-medium text-gray-700 hover:text-gray-500"
              >
                Abbrechen
              </button>
              <button
                onClick={handleReport}
                className="px-4 py-2 text-sm font-medium text-white bg-red-600 rounded-md hover:bg-red-700"
              >
                Melden
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ReviewSystem;