import React from 'react';
import { Star, ThumbsUp, Flag } from 'lucide-react';

interface Review {
  id: string;
  author: string;
  avatar: string;
  rating: number;
  date: string;
  content: string;
  helpful: number;
  listing: string;
}

const MOCK_REVIEWS: Review[] = [
  {
    id: '1',
    author: 'Max Mustermann',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=facearea&facepad=2&w=48&h=48&q=80',
    rating: 5,
    date: '2024-03-15',
    content: 'Sehr professioneller Vermieter. Die Wohnung war genau wie beschrieben und der gesamte Prozess verlief reibungslos.',
    helpful: 12,
    listing: 'Moderne 3-Zimmer Wohnung',
  },
  {
    id: '2',
    author: 'Anna Schmidt',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=facearea&facepad=2&w=48&h=48&q=80',
    rating: 4,
    date: '2024-03-14',
    content: 'Gute Kommunikation und faire Konditionen. Ein kleiner Punkt Abzug für die etwas längere Wartezeit bei der Schlüsselübergabe.',
    helpful: 8,
    listing: 'Penthouse mit Dachterrasse',
  },
];

const ReviewList = () => {
  return (
    <div className="bg-white rounded-lg shadow-sm">
      <div className="p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-6">Bewertungen</h2>

        <div className="space-y-6">
          {MOCK_REVIEWS.map((review) => (
            <div key={review.id} className="border-b border-gray-200 pb-6 last:border-0 last:pb-0">
              <div className="flex items-start">
                <img
                  src={review.avatar}
                  alt={review.author}
                  className="h-10 w-10 rounded-full"
                />
                <div className="ml-4 flex-1">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-sm font-medium text-gray-900">{review.author}</h3>
                      <div className="flex items-center mt-1">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`h-4 w-4 ${
                              i < review.rating ? 'text-yellow-400' : 'text-gray-300'
                            }`}
                            fill={i < review.rating ? 'currentColor' : 'none'}
                          />
                        ))}
                      </div>
                    </div>
                    <p className="text-sm text-gray-500">
                      {new Date(review.date).toLocaleDateString()}
                    </p>
                  </div>
                  <p className="mt-2 text-sm text-gray-600">{review.content}</p>
                  <p className="mt-2 text-xs text-gray-500">Bewertung für: {review.listing}</p>
                  <div className="mt-4 flex items-center space-x-4">
                    <button className="inline-flex items-center text-sm text-gray-500 hover:text-gray-700">
                      <ThumbsUp className="h-4 w-4 mr-1.5" />
                      Hilfreich ({review.helpful})
                    </button>
                    <button className="inline-flex items-center text-sm text-gray-500 hover:text-gray-700">
                      <Flag className="h-4 w-4 mr-1.5" />
                      Melden
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ReviewList;