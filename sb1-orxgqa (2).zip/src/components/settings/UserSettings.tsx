import React, { useState } from 'react';
import { User, Mail, Bell, Lock, Shield, Trash2 } from 'lucide-react';

interface UserSettingsProps {
  initialData?: {
    email: string;
    notifications: {
      email: boolean;
      push: boolean;
      messages: boolean;
      marketing: boolean;
    };
  };
}

const UserSettings: React.FC<UserSettingsProps> = ({ initialData }) => {
  const [activeTab, setActiveTab] = useState('profile');
  const [notifications, setNotifications] = useState(initialData?.notifications || {
    email: true,
    push: true,
    messages: true,
    marketing: false,
  });

  return (
    <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-sm">
      <div className="border-b border-gray-200">
        <nav className="-mb-px flex space-x-8 px-6" aria-label="Tabs">
          <button
            onClick={() => setActiveTab('profile')}
            className={`${
              activeTab === 'profile'
                ? 'border-indigo-500 text-indigo-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm flex items-center`}
          >
            <User className="h-5 w-5 mr-2" />
            Profil
          </button>
          <button
            onClick={() => setActiveTab('notifications')}
            className={`${
              activeTab === 'notifications'
                ? 'border-indigo-500 text-indigo-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm flex items-center`}
          >
            <Bell className="h-5 w-5 mr-2" />
            Benachrichtigungen
          </button>
          <button
            onClick={() => setActiveTab('security')}
            className={`${
              activeTab === 'security'
                ? 'border-indigo-500 text-indigo-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm flex items-center`}
          >
            <Shield className="h-5 w-5 mr-2" />
            Sicherheit
          </button>
        </nav>
      </div>

      <div className="p-6">
        {activeTab === 'profile' && (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-medium text-gray-900">Profilinformationen</h3>
              <p className="mt-1 text-sm text-gray-500">
                Aktualisieren Sie Ihre persönlichen Informationen.
              </p>
            </div>

            <div className="grid grid-cols-1 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  E-Mail-Adresse
                </label>
                <div className="mt-1 relative rounded-md shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Mail className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="email"
                    defaultValue={initialData?.email}
                    className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Passwort ändern
                </label>
                <div className="mt-1 relative rounded-md shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Lock className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="password"
                    placeholder="Neues Passwort"
                    className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                  />
                </div>
              </div>
            </div>

            <div className="flex justify-end">
              <button
                type="button"
                className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700"
              >
                Änderungen speichern
              </button>
            </div>
          </div>
        )}

        {activeTab === 'notifications' && (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-medium text-gray-900">Benachrichtigungseinstellungen</h3>
              <p className="mt-1 text-sm text-gray-500">
                Legen Sie fest, wie und wann Sie benachrichtigt werden möchten.
              </p>
            </div>

            <div className="space-y-4">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={notifications.email}
                  onChange={(e) =>
                    setNotifications({ ...notifications, email: e.target.checked })
                  }
                  className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                />
                <span className="ml-2 text-sm text-gray-700">
                  E-Mail-Benachrichtigungen
                </span>
              </label>

              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={notifications.push}
                  onChange={(e) =>
                    setNotifications({ ...notifications, push: e.target.checked })
                  }
                  className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                />
                <span className="ml-2 text-sm text-gray-700">
                  Push-Benachrichtigungen
                </span>
              </label>

              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={notifications.messages}
                  onChange={(e) =>
                    setNotifications({ ...notifications, messages: e.target.checked })
                  }
                  className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                />
                <span className="ml-2 text-sm text-gray-700">
                  Nachrichten-Benachrichtigungen
                </span>
              </label>

              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={notifications.marketing}
                  onChange={(e) =>
                    setNotifications({ ...notifications, marketing: e.target.checked })
                  }
                  className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                />
                <span className="ml-2 text-sm text-gray-700">
                  Marketing-Benachrichtigungen
                </span>
              </label>
            </div>

            <div className="flex justify-end">
              <button
                type="button"
                className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700"
              >
                Einstellungen speichern
              </button>
            </div>
          </div>
        )}

        {activeTab === 'security' && (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-medium text-gray-900">Sicherheitseinstellungen</h3>
              <p className="mt-1 text-sm text-gray-500">
                Verwalten Sie die Sicherheitseinstellungen Ihres Kontos.
              </p>
            </div>

            <div className="space-y-4">
              <div className="border-t border-b border-gray-200 py-4">
                <button className="flex items-center text-red-600 hover:text-red-700">
                  <Trash2 className="h-5 w-5 mr-2" />
                  <span>Konto löschen</span>
                </button>
                <p className="mt-1 text-sm text-gray-500">
                  Löscht Ihr Konto und alle damit verbundenen Daten unwiderruflich.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default UserSettings;