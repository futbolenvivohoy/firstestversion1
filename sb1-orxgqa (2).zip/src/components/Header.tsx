import React from 'react';
import { Home } from 'lucide-react';
import SearchBar from './search/SearchBar';
import UserMenu from './navigation/UserMenu';

const Header = () => {
  return (
    <header className="sticky top-0 z-50 bg-white shadow-sm">
      {/* Top Bar */}
      <div className="border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div className="flex-shrink-0">
              <a href="/" className="flex items-center space-x-2">
                <Home className="h-6 w-6 text-indigo-600" />
                <span className="text-xl font-bold text-indigo-600">RealtyHub</span>
              </a>
            </div>

            {/* User Navigation */}
            <UserMenu />
          </div>
        </div>
      </div>

      {/* Search Bar Section */}
      <div className="bg-gradient-to-r from-green-50 via-green-100 to-green-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
          <SearchBar />
        </div>
      </div>
    </header>
  );
};

export default Header;