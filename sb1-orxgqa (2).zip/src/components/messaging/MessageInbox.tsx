import React from 'react';
import { MessageSquare, Star, Clock, ChevronRight } from 'lucide-react';

const MOCK_MESSAGES = [
  {
    id: '1',
    sender: 'Max Mustermann',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=facearea&facepad=2&w=48&h=48&q=80',
    preview: 'Ist die Wohnung noch verfügbar?',
    listing: 'Moderne 3-Zimmer Wohnung',
    date: '2024-03-16T14:30:00',
    unread: true,
  },
  {
    id: '2',
    sender: 'Anna Schmidt',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=facearea&facepad=2&w=48&h=48&q=80',
    preview: 'Können wir einen Besichtigungstermin vereinbaren?',
    listing: 'Penthouse mit Dachterrasse',
    date: '2024-03-15T09:15:00',
    unread: false,
  },
];

const MessageInbox = () => {
  return (
    <div className="bg-white rounded-lg shadow-sm">
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold text-gray-900">Nachrichten</h2>
          <div className="flex space-x-2">
            <button className="inline-flex items-center px-3 py-1.5 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
              <Star className="h-4 w-4 mr-1.5 text-gray-400" />
              Favoriten
            </button>
            <button className="inline-flex items-center px-3 py-1.5 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
              <Clock className="h-4 w-4 mr-1.5 text-gray-400" />
              Ungelesen
            </button>
          </div>
        </div>

        <div className="divide-y divide-gray-200">
          {MOCK_MESSAGES.map((message) => (
            <div
              key={message.id}
              className={`py-4 flex items-center hover:bg-gray-50 cursor-pointer ${
                message.unread ? 'bg-indigo-50' : ''
              }`}
            >
              <div className="flex-shrink-0">
                <img
                  src={message.avatar}
                  alt={message.sender}
                  className="h-10 w-10 rounded-full"
                />
              </div>
              <div className="ml-4 flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-medium text-gray-900 truncate">
                    {message.sender}
                  </p>
                  <p className="text-sm text-gray-500">
                    {new Date(message.date).toLocaleDateString()}
                  </p>
                </div>
                <div className="mt-1">
                  <p className="text-sm text-gray-600 truncate">{message.preview}</p>
                </div>
                <div className="mt-1 flex items-center">
                  <MessageSquare className="h-4 w-4 text-gray-400 mr-1.5" />
                  <p className="text-xs text-gray-500">{message.listing}</p>
                </div>
              </div>
              <div className="ml-4">
                <ChevronRight className="h-5 w-5 text-gray-400" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default MessageInbox;