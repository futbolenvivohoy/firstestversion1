import React, { useState } from 'react';
import { Send, Image, Paperclip } from 'lucide-react';

interface Message {
  id: string;
  content: string;
  sender: 'user' | 'other';
  timestamp: string;
}

const MOCK_THREAD: Message[] = [
  {
    id: '1',
    content: 'Ist die Wohnung noch verfügbar?',
    sender: 'other',
    timestamp: '2024-03-16T14:30:00',
  },
  {
    id: '2',
    content: 'Ja, die Wohnung ist noch verfügbar. Möchten Sie einen Besichtigungstermin vereinbaren?',
    sender: 'user',
    timestamp: '2024-03-16T14:35:00',
  },
];

const MessageThread = () => {
  const [newMessage, setNewMessage] = useState('');

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle sending message
    setNewMessage('');
  };

  return (
    <div className="flex flex-col h-[600px] bg-white rounded-lg shadow-sm">
      {/* Header */}
      <div className="p-4 border-b">
        <div className="flex items-center">
          <img
            src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=facearea&facepad=2&w=48&h=48&q=80"
            alt="Sender"
            className="h-10 w-10 rounded-full"
          />
          <div className="ml-3">
            <p className="text-sm font-medium text-gray-900">Max Mustermann</p>
            <p className="text-xs text-gray-500">Moderne 3-Zimmer Wohnung</p>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {MOCK_THREAD.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[70%] rounded-lg px-4 py-2 ${
                message.sender === 'user'
                  ? 'bg-indigo-600 text-white'
                  : 'bg-gray-100 text-gray-900'
              }`}
            >
              <p className="text-sm">{message.content}</p>
              <p className="text-xs mt-1 opacity-70">
                {new Date(message.timestamp).toLocaleTimeString()}
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* Input */}
      <div className="p-4 border-t">
        <form onSubmit={handleSend} className="flex items-center space-x-4">
          <div className="flex space-x-2">
            <button
              type="button"
              className="p-2 text-gray-400 hover:text-gray-500 rounded-full hover:bg-gray-100"
            >
              <Image className="h-5 w-5" />
            </button>
            <button
              type="button"
              className="p-2 text-gray-400 hover:text-gray-500 rounded-full hover:bg-gray-100"
            >
              <Paperclip className="h-5 w-5" />
            </button>
          </div>
          <input
            type="text"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="Ihre Nachricht..."
            className="flex-1 border-0 focus:ring-0 text-sm"
          />
          <button
            type="submit"
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700"
          >
            <Send className="h-4 w-4 mr-1.5" />
            Senden
          </button>
        </form>
      </div>
    </div>
  );
};

export default MessageThread;