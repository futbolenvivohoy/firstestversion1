import React from 'react';
import { 
  Home, 
  MessageSquare, 
  Settings, 
  Bell, 
  PlusCircle,
  List,
  BarChart
} from 'lucide-react';

const UserDashboard = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {/* Quick Actions */}
          <div className="col-span-full lg:col-span-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <button className="flex items-center p-6 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow">
                <PlusCircle className="h-6 w-6 text-indigo-600 mr-3" />
                <span className="text-gray-900 font-medium">Neue Anzeige</span>
              </button>
              <button className="flex items-center p-6 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow">
                <List className="h-6 w-6 text-indigo-600 mr-3" />
                <span className="text-gray-900 font-medium">Meine Anzeigen</span>
              </button>
              <button className="flex items-center p-6 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow">
                <MessageSquare className="h-6 w-6 text-indigo-600 mr-3" />
                <span className="text-gray-900 font-medium">Nachrichten</span>
              </button>
            </div>
          </div>

          {/* Statistics */}
          <div className="col-span-full lg:col-span-4">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Statistiken</h3>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div className="p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center">
                    <Home className="h-5 w-5 text-indigo-600 mr-2" />
                    <span className="text-sm text-gray-500">Aktive Anzeigen</span>
                  </div>
                  <p className="mt-2 text-2xl font-semibold text-gray-900">12</p>
                </div>
                <div className="p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center">
                    <BarChart className="h-5 w-5 text-indigo-600 mr-2" />
                    <span className="text-sm text-gray-500">Aufrufe</span>
                  </div>
                  <p className="mt-2 text-2xl font-semibold text-gray-900">1.234</p>
                </div>
                <div className="p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center">
                    <MessageSquare className="h-5 w-5 text-indigo-600 mr-2" />
                    <span className="text-sm text-gray-500">Nachrichten</span>
                  </div>
                  <p className="mt-2 text-2xl font-semibold text-gray-900">23</p>
                </div>
                <div className="p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center">
                    <Bell className="h-5 w-5 text-indigo-600 mr-2" />
                    <span className="text-sm text-gray-500">Benachrichtigungen</span>
                  </div>
                  <p className="mt-2 text-2xl font-semibold text-gray-900">5</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserDashboard;