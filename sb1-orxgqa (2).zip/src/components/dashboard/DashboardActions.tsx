import React from 'react';
import { Link } from 'react-router-dom';
import { PlusCircle, List, MessageSquare, Settings, Heart } from 'lucide-react';

const DashboardActions = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-6">
      <Link
        to="/listings/create"
        className="flex items-center p-6 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow"
      >
        <PlusCircle className="h-6 w-6 text-indigo-600 mr-3" />
        <span className="text-gray-900 font-medium">Neue Anzeige</span>
      </Link>

      <Link
        to="/listings/manage"
        className="flex items-center p-6 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow"
      >
        <List className="h-6 w-6 text-indigo-600 mr-3" />
        <span className="text-gray-900 font-medium">Meine Anzeigen</span>
      </Link>

      <Link
        to="/messages"
        className="flex items-center p-6 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow"
      >
        <MessageSquare className="h-6 w-6 text-indigo-600 mr-3" />
        <span className="text-gray-900 font-medium">Nachrichten</span>
      </Link>

      <Link
        to="/favorites"
        className="flex items-center p-6 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow"
      >
        <Heart className="h-6 w-6 text-indigo-600 mr-3" />
        <span className="text-gray-900 font-medium">Favoriten</span>
      </Link>

      <Link
        to="/settings"
        className="flex items-center p-6 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow"
      >
        <Settings className="h-6 w-6 text-indigo-600 mr-3" />
        <span className="text-gray-900 font-medium">Einstellungen</span>
      </Link>
    </div>
  );
};

export default DashboardActions;