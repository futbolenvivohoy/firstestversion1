import React from 'react';
import { MessageSquare, Eye, Heart, Clock } from 'lucide-react';

const MOCK_ACTIVITIES = [
  {
    id: 1,
    type: 'message',
    content: 'Neue Nachricht von Max Mustermann',
    time: '5 Minuten',
    listing: 'Moderne 3-Zimmer Wohnung',
  },
  {
    id: 2,
    type: 'view',
    content: '15 neue Aufrufe Ihrer Anzeige',
    time: '1 Stunde',
    listing: 'Penthouse mit Dachterrasse',
  },
  {
    id: 3,
    type: 'favorite',
    content: 'Ihre Anzeige wurde favorisiert',
    time: '2 Stunden',
    listing: 'Moderne 3-Zimmer Wohnung',
  },
];

const RecentActivity = () => {
  const getIcon = (type: string) => {
    switch (type) {
      case 'message':
        return <MessageSquare className="h-5 w-5 text-blue-500" />;
      case 'view':
        return <Eye className="h-5 w-5 text-green-500" />;
      case 'favorite':
        return <Heart className="h-5 w-5 text-red-500" />;
      default:
        return null;
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm">
      <div className="p-6">
        <h3 className="text-lg font-medium text-gray-900 mb-6">Letzte Aktivitäten</h3>
        <div className="space-y-6">
          {MOCK_ACTIVITIES.map((activity) => (
            <div key={activity.id} className="flex items-start">
              <div className="flex-shrink-0">{getIcon(activity.type)}</div>
              <div className="ml-4 flex-1">
                <p className="text-sm text-gray-900">{activity.content}</p>
                <p className="text-xs text-gray-500">{activity.listing}</p>
                <div className="mt-1 flex items-center text-xs text-gray-500">
                  <Clock className="h-3 w-3 mr-1" />
                  vor {activity.time}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default RecentActivity;