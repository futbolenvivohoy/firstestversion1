import React, { useState } from 'react';
import { Download, Upload, Trash2, RefreshCw } from 'lucide-react';

interface Backup {
  id: string;
  timestamp: string;
  size: string;
  type: 'auto' | 'manual';
}

const MOCK_BACKUPS: Backup[] = [
  {
    id: '1',
    timestamp: '2024-03-16T14:30:00',
    size: '2.5 MB',
    type: 'auto',
  },
  {
    id: '2',
    timestamp: '2024-03-15T12:00:00',
    size: '2.3 MB',
    type: 'manual',
  },
];

const BackupManager = () => {
  const [isRestoring, setIsRestoring] = useState(false);
  const [selectedBackup, setSelectedBackup] = useState<string | null>(null);

  const handleCreateBackup = () => {
    // Handle backup creation
  };

  const handleRestore = (backupId: string) => {
    setIsRestoring(true);
    setSelectedBackup(backupId);
    // Handle backup restoration
    setTimeout(() => {
      setIsRestoring(false);
      setSelectedBackup(null);
    }, 2000);
  };

  const handleDelete = (backupId: string) => {
    // Handle backup deletion
  };

  return (
    <div className="bg-white rounded-lg shadow-sm">
      <div className="p-6">
        <div className="sm:flex sm:items-center">
          <div className="sm:flex-auto">
            <h2 className="text-xl font-semibold text-gray-900">Backup-Verwaltung</h2>
            <p className="mt-2 text-sm text-gray-700">
              Verwalten Sie Ihre Systembackups und stellen Sie bei Bedarf Daten wieder her.
            </p>
          </div>
          <div className="mt-4 sm:mt-0 sm:ml-16 sm:flex-none">
            <button
              onClick={handleCreateBackup}
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700"
            >
              <Download className="h-4 w-4 mr-2" />
              Backup erstellen
            </button>
          </div>
        </div>

        <div className="mt-8 flow-root">
          <div className="-mx-4 -my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
            <div className="inline-block min-w-full py-2 align-middle">
              <table className="min-w-full divide-y divide-gray-300">
                <thead>
                  <tr>
                    <th className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900">
                      Datum
                    </th>
                    <th className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                      Typ
                    </th>
                    <th className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                      Größe
                    </th>
                    <th className="relative py-3.5 pl-3 pr-4">
                      <span className="sr-only">Aktionen</span>
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {MOCK_BACKUPS.map((backup) => (
                    <tr key={backup.id}>
                      <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm text-gray-900">
                        {new Date(backup.timestamp).toLocaleString()}
                      </td>
                      <td className="whitespace-nowrap px-3 py-4 text-sm">
                        <span
                          className={`inline-flex rounded-full px-2 text-xs font-semibold leading-5 ${
                            backup.type === 'auto'
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-green-100 text-green-800'
                          }`}
                        >
                          {backup.type === 'auto' ? 'Automatisch' : 'Manuell'}
                        </span>
                      </td>
                      <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                        {backup.size}
                      </td>
                      <td className="relative whitespace-nowrap py-4 pl-3 pr-4 text-right text-sm font-medium">
                        <div className="flex justify-end space-x-2">
                          <button
                            onClick={() => handleRestore(backup.id)}
                            disabled={isRestoring}
                            className={`text-indigo-600 hover:text-indigo-900 ${
                              isRestoring && selectedBackup === backup.id
                                ? 'opacity-50 cursor-not-allowed'
                                : ''
                            }`}
                          >
                            {isRestoring && selectedBackup === backup.id ? (
                              <RefreshCw className="h-5 w-5 animate-spin" />
                            ) : (
                              <Upload className="h-5 w-5" />
                            )}
                          </button>
                          <button
                            onClick={() => handleDelete(backup.id)}
                            className="text-red-600 hover:text-red-900"
                          >
                            <Trash2 className="h-5 w-5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BackupManager;