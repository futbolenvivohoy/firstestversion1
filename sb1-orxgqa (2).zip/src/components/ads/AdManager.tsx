import React, { useState } from 'react';
import { DollarSign, Calendar, BarChart2, Settings } from 'lucide-react';

interface Ad {
  id: string;
  title: string;
  budget: number;
  startDate: string;
  endDate: string;
  status: 'active' | 'paused' | 'completed';
  impressions: number;
  clicks: number;
}

const MOCK_ADS: Ad[] = [
  {
    id: '1',
    title: 'Premium Listing Boost',
    budget: 500,
    startDate: '2024-03-01',
    endDate: '2024-03-31',
    status: 'active',
    impressions: 1234,
    clicks: 45,
  },
  {
    id: '2',
    title: 'Featured Agency Profile',
    budget: 750,
    startDate: '2024-03-15',
    endDate: '2024-04-15',
    status: 'active',
    impressions: 2156,
    clicks: 89,
  },
];

const AdManager = () => {
  const [selectedAd, setSelectedAd] = useState<string | null>(null);

  return (
    <div className="bg-white rounded-lg shadow-sm">
      <div className="p-6">
        <div className="sm:flex sm:items-center">
          <div className="sm:flex-auto">
            <h2 className="text-xl font-semibold text-gray-900">Anzeigenverwaltung</h2>
            <p className="mt-2 text-sm text-gray-700">
              Verwalten Sie Ihre Werbekampagnen und Anzeigenplatzierungen.
            </p>
          </div>
          <div className="mt-4 sm:mt-0 sm:ml-16 sm:flex-none">
            <button className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700">
              Neue Kampagne
            </button>
          </div>
        </div>

        <div className="mt-8 flow-root">
          <div className="-mx-4 -my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
            <div className="inline-block min-w-full py-2 align-middle">
              <table className="min-w-full divide-y divide-gray-300">
                <thead>
                  <tr>
                    <th className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900">
                      Kampagne
                    </th>
                    <th className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                      Budget
                    </th>
                    <th className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                      Zeitraum
                    </th>
                    <th className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                      Status
                    </th>
                    <th className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                      Performance
                    </th>
                    <th className="relative py-3.5 pl-3 pr-4">
                      <span className="sr-only">Aktionen</span>
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {MOCK_ADS.map((ad) => (
                    <tr key={ad.id}>
                      <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm">
                        <div className="font-medium text-gray-900">{ad.title}</div>
                      </td>
                      <td className="whitespace-nowrap px-3 py-4 text-sm">
                        <div className="flex items-center">
                          <DollarSign className="h-4 w-4 text-gray-400 mr-1" />
                          {ad.budget.toLocaleString()} €
                        </div>
                      </td>
                      <td className="whitespace-nowrap px-3 py-4 text-sm">
                        <div className="flex items-center">
                          <Calendar className="h-4 w-4 text-gray-400 mr-1" />
                          {new Date(ad.startDate).toLocaleDateString()} -{' '}
                          {new Date(ad.endDate).toLocaleDateString()}
                        </div>
                      </td>
                      <td className="whitespace-nowrap px-3 py-4 text-sm">
                        <span
                          className={`inline-flex rounded-full px-2 text-xs font-semibold leading-5 ${
                            ad.status === 'active'
                              ? 'bg-green-100 text-green-800'
                              : ad.status === 'paused'
                              ? 'bg-yellow-100 text-yellow-800'
                              : 'bg-gray-100 text-gray-800'
                          }`}
                        >
                          {ad.status === 'active'
                            ? 'Aktiv'
                            : ad.status === 'paused'
                            ? 'Pausiert'
                            : 'Beendet'}
                        </span>
                      </td>
                      <td className="whitespace-nowrap px-3 py-4 text-sm">
                        <div className="flex items-center">
                          <BarChart2 className="h-4 w-4 text-gray-400 mr-1" />
                          {ad.impressions.toLocaleString()} Impressions,{' '}
                          {ad.clicks.toLocaleString()} Clicks
                        </div>
                      </td>
                      <td className="relative whitespace-nowrap py-4 pl-3 pr-4 text-right text-sm font-medium">
                        <button
                          onClick={() => setSelectedAd(ad.id)}
                          className="text-indigo-600 hover:text-indigo-900"
                        >
                          <Settings className="h-5 w-5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdManager;