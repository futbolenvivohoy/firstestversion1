import React from 'react';

export const VerificationEmail = ({ username, verificationLink }: { username: string; verificationLink: string }) => (
  <div>
    <h1>Willkommen bei RealtyHub, {username}!</h1>
    <p>Bitte bestätigen Sie Ihre E-Mail-Adresse, um Ihr Konto zu aktivieren.</p>
    <a href={verificationLink}>E-Mail bestätigen</a>
  </div>
);

export const WelcomeEmail = ({ username }: { username: string }) => (
  <div>
    <h1>Herzlich willkommen, {username}!</h1>
    <p>Ihr Konto wurde erfolgreich aktiviert. Sie können nun Immobilienanzeigen erstellen und verwalten.</p>
  </div>
);

export const ListingApprovedEmail = ({ listingTitle, listingUrl }: { listingTitle: string; listingUrl: string }) => (
  <div>
    <h1>Ihre Anzeige wurde genehmigt</h1>
    <p>Ihre Anzeige "{listingTitle}" wurde erfolgreich überprüft und ist nun online.</p>
    <a href={listingUrl}>Anzeige ansehen</a>
  </div>
);

export const NewMessageEmail = ({ senderName, messagePreview, threadUrl }: { senderName: string; messagePreview: string; threadUrl: string }) => (
  <div>
    <h1>Neue Nachricht von {senderName}</h1>
    <p>Sie haben eine neue Nachricht erhalten:</p>
    <blockquote>"{messagePreview}"</blockquote>
    <a href={threadUrl}>Zur Konversation</a>
  </div>
);

export const ListingExpirationEmail = ({ listingTitle, daysLeft }: { listingTitle: string; daysLeft: number }) => (
  <div>
    <h1>Ihre Anzeige läuft bald ab</h1>
    <p>Ihre Anzeige "{listingTitle}" läuft in {daysLeft} Tagen ab.</p>
    <p>Verlängern Sie die Laufzeit, um weiterhin Interessenten zu erreichen.</p>
  </div>
);