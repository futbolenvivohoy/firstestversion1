import React from 'react';
import ListingCard from './listings/ListingCard';

const NEW_LISTINGS = [
  {
    id: 1,
    image: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=800&q=80',
    title: 'Neubau Apartment',
    location: 'Berlin, Mitte',
    price: 1450,
  },
  {
    id: 2,
    image: 'https://images.unsplash.com/photo-1493809842364-78817add7ffb?auto=format&fit=crop&w=800&q=80',
    title: 'Moderne 3-Zimmer',
    location: 'Hamburg, Eppendorf',
    price: 1800,
  },
  {
    id: 3,
    image: 'https://images.unsplash.com/photo-1484154218962-a197022b5858?auto=format&fit=crop&w=800&q=80',
    title: 'Penthouse mit Terrasse',
    location: 'München, Schwabing',
    price: 2200,
  },
  {
    id: 4,
    image: 'https://images.unsplash.com/photo-1570129477492-45c003edd2be?auto=format&fit=crop&w=800&q=80',
    title: 'Loft im Altbau',
    location: 'Berlin, Prenzlauer Berg',
    price: 1650,
  },
];

const NewListings = () => {
  return (
    <section className="bg-white rounded-lg shadow-sm">
      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold text-gray-900">Neueste Anzeigen</h2>
          <a href="#" className="text-sm font-medium text-indigo-600 hover:text-indigo-500">
            Alle anzeigen
          </a>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {NEW_LISTINGS.map((listing) => (
            <ListingCard key={listing.id} {...listing} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default NewListings;