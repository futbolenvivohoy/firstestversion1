import React, { useState } from 'react';
import { Building2, User, Mail, Lock, Phone, MapPin } from 'lucide-react';

type UserType = 'private' | 'agency';

const RegisterForm = () => {
  const [userType, setUserType] = useState<UserType>('private');
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    confirmPassword: '',
    phone: '',
    companyName: '',
    address: '',
    description: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle registration logic
  };

  return (
    <div className="max-w-md w-full mx-auto bg-white p-8 rounded-lg shadow-sm">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-gray-900">Konto erstellen</h2>
        <p className="mt-2 text-sm text-gray-600">
          Bereits registriert?{' '}
          <a href="/login" className="text-indigo-600 hover:text-indigo-500">
            Einloggen
          </a>
        </p>
      </div>

      <div className="flex gap-4 mb-6">
        <button
          type="button"
          onClick={() => setUserType('private')}
          className={`flex-1 py-3 px-4 rounded-lg border ${
            userType === 'private'
              ? 'border-indigo-600 bg-indigo-50 text-indigo-600'
              : 'border-gray-300 text-gray-700'
          }`}
        >
          <User className="h-5 w-5 mx-auto mb-2" />
          <span className="block text-sm font-medium">Privat</span>
        </button>
        <button
          type="button"
          onClick={() => setUserType('agency')}
          className={`flex-1 py-3 px-4 rounded-lg border ${
            userType === 'agency'
              ? 'border-indigo-600 bg-indigo-50 text-indigo-600'
              : 'border-gray-300 text-gray-700'
          }`}
        >
          <Building2 className="h-5 w-5 mx-auto mb-2" />
          <span className="block text-sm font-medium">Gewerbe</span>
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {userType === 'agency' && (
          <div>
            <label htmlFor="companyName" className="block text-sm font-medium text-gray-700">
              Firmenname
            </label>
            <div className="mt-1 relative">
              <input
                type="text"
                id="companyName"
                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
                required
              />
              <Building2 className="absolute right-3 top-2.5 h-5 w-5 text-gray-400" />
            </div>
          </div>
        )}

        <div>
          <label htmlFor="email" className="block text-sm font-medium text-gray-700">
            E-Mail
          </label>
          <div className="mt-1 relative">
            <input
              type="email"
              id="email"
              className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
              required
            />
            <Mail className="absolute right-3 top-2.5 h-5 w-5 text-gray-400" />
          </div>
        </div>

        <div>
          <label htmlFor="password" className="block text-sm font-medium text-gray-700">
            Passwort
          </label>
          <div className="mt-1 relative">
            <input
              type="password"
              id="password"
              className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
              required
            />
            <Lock className="absolute right-3 top-2.5 h-5 w-5 text-gray-400" />
          </div>
        </div>

        <div>
          <label htmlFor="phone" className="block text-sm font-medium text-gray-700">
            Telefon
          </label>
          <div className="mt-1 relative">
            <input
              type="tel"
              id="phone"
              className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
              required
            />
            <Phone className="absolute right-3 top-2.5 h-5 w-5 text-gray-400" />
          </div>
        </div>

        {userType === 'agency' && (
          <>
            <div>
              <label htmlFor="address" className="block text-sm font-medium text-gray-700">
                Adresse
              </label>
              <div className="mt-1 relative">
                <input
                  type="text"
                  id="address"
                  className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
                  required
                />
                <MapPin className="absolute right-3 top-2.5 h-5 w-5 text-gray-400" />
              </div>
            </div>

            <div>
              <label htmlFor="description" className="block text-sm font-medium text-gray-700">
                Beschreibung
              </label>
              <div className="mt-1">
                <textarea
                  id="description"
                  rows={4}
                  className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
                />
              </div>
            </div>
          </>
        )}

        <div>
          <button
            type="submit"
            className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            Registrieren
          </button>
        </div>
      </form>
    </div>
  );
};

export default RegisterForm;