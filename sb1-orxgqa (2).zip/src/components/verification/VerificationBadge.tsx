import React from 'react';
import { Shield, CheckCircle } from 'lucide-react';

interface VerificationBadgeProps {
  type: 'user' | 'agency';
  verified: boolean;
  className?: string;
}

const VerificationBadge: React.FC<VerificationBadgeProps> = ({
  type,
  verified,
  className = '',
}) => {
  if (!verified) return null;

  return (
    <div
      className={`inline-flex items-center ${
        type === 'agency' ? 'text-indigo-600' : 'text-green-600'
      } ${className}`}
    >
      {type === 'agency' ? (
        <Shield className="h-4 w-4 mr-1" />
      ) : (
        <CheckCircle className="h-4 w-4 mr-1" />
      )}
      <span className="text-xs font-medium">
        {type === 'agency' ? 'Verifizierte Agentur' : 'Verifizierter Nutzer'}
      </span>
    </div>
  );
};

export default VerificationBadge;