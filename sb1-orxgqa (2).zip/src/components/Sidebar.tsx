import React from 'react';
import { Home, Building2, Hotel, Warehouse } from 'lucide-react';

const categories = [
  { name: 'Wohnungen', icon: Home, count: 234 },
  { name: 'Häuser', icon: Building2, count: 156 },
  { name: 'Apartments', icon: Hotel, count: 89 },
  { name: 'Gewerbe', icon: Warehouse, count: 45 },
];

const Sidebar = () => {
  return (
    <div className="w-64 flex-shrink-0 hidden lg:block">
      <nav className="mt-8">
        <div className="px-4 mb-4">
          <h2 className="text-lg font-semibold text-gray-900">Kategorien</h2>
        </div>
        <div className="space-y-1">
          {categories.map((category) => (
            <a
              key={category.name}
              href="#"
              className="group flex items-center px-4 py-2 text-sm font-medium text-gray-600 hover:bg-gray-50 hover:text-gray-900"
            >
              <category.icon className="mr-3 h-5 w-5" />
              <span className="flex-1">{category.name}</span>
              <span className="ml-3 inline-block py-0.5 px-2 text-xs rounded-full bg-gray-100">
                {category.count}
              </span>
            </a>
          ))}
        </div>
      </nav>
    </div>
  );
};

export default Sidebar;