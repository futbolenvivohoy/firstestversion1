import React from 'react';
import { Bell, MessageSquare, Heart, AlertCircle, Check, X } from 'lucide-react';

interface Notification {
  id: string;
  type: 'message' | 'like' | 'alert' | 'system';
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
}

const MOCK_NOTIFICATIONS: Notification[] = [
  {
    id: '1',
    type: 'message',
    title: 'Neue Nachricht',
    message: 'Sie haben eine neue Nachricht von Max Mustermann.',
    timestamp: '2024-03-16T14:30:00',
    read: false,
  },
  {
    id: '2',
    type: 'like',
    title: 'Neue Favorisierung',
    message: 'Ihre Anzeige wurde zu den Favoriten hinzugefügt.',
    timestamp: '2024-03-16T12:15:00',
    read: true,
  },
  {
    id: '3',
    type: 'alert',
    title: 'Anzeige genehmigt',
    message: 'Ihre Anzeige wurde erfolgreich genehmigt.',
    timestamp: '2024-03-15T18:45:00',
    read: true,
  },
];

const NotificationCenter = () => {
  const unreadCount = MOCK_NOTIFICATIONS.filter((n) => !n.read).length;

  const getIcon = (type: string) => {
    switch (type) {
      case 'message':
        return <MessageSquare className="h-5 w-5 text-blue-500" />;
      case 'like':
        return <Heart className="h-5 w-5 text-red-500" />;
      case 'alert':
        return <AlertCircle className="h-5 w-5 text-yellow-500" />;
      default:
        return <Bell className="h-5 w-5 text-gray-500" />;
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm">
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Bell className="h-6 w-6 text-gray-400" />
            <h2 className="ml-2 text-lg font-medium text-gray-900">Benachrichtigungen</h2>
            {unreadCount > 0 && (
              <span className="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
                {unreadCount} Neu
              </span>
            )}
          </div>
          <button className="text-sm text-indigo-600 hover:text-indigo-500">
            Alle als gelesen markieren
          </button>
        </div>
      </div>

      <div className="divide-y divide-gray-200">
        {MOCK_NOTIFICATIONS.map((notification) => (
          <div
            key={notification.id}
            className={`p-4 ${
              !notification.read ? 'bg-indigo-50' : 'hover:bg-gray-50'
            }`}
          >
            <div className="flex items-start">
              <div className="flex-shrink-0">{getIcon(notification.type)}</div>
              <div className="ml-3 flex-1">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-medium text-gray-900">
                    {notification.title}
                  </p>
                  <div className="ml-4 flex items-center">
                    {!notification.read && (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                        Neu
                      </span>
                    )}
                    <button className="ml-2 text-gray-400 hover:text-gray-500">
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                </div>
                <p className="mt-1 text-sm text-gray-500">{notification.message}</p>
                <p className="mt-1 text-xs text-gray-400">
                  {new Date(notification.timestamp).toLocaleString()}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {MOCK_NOTIFICATIONS.length === 0 && (
        <div className="p-4 text-center text-gray-500">
          Keine Benachrichtigungen vorhanden
        </div>
      )}
    </div>
  );
};

export default NotificationCenter;