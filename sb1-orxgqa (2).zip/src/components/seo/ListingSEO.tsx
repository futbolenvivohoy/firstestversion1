import React from 'react';
import { Helmet } from 'react-helmet-async';
import { generateListingSEO, generateListingSchema } from '../../utils/seo';
import { Listing } from '../../types';

interface ListingSEOProps {
  listing: Listing;
}

const ListingSEO: React.FC<ListingSEOProps> = ({ listing }) => {
  const seo = generateListingSEO(listing);
  const schema = generateListingSchema(listing);

  return (
    <Helmet>
      <title>{seo.title}</title>
      <meta name="description" content={seo.description} />
      <meta name="keywords" content={seo.keywords} />
      
      {/* Open Graph / Facebook */}
      <meta property="og:type" content="website" />
      <meta property="og:title" content={seo.title} />
      <meta property="og:description" content={seo.description} />
      {listing.images[0] && <meta property="og:image" content={listing.images[0]} />}
      
      {/* Twitter */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={seo.title} />
      <meta name="twitter:description" content={seo.description} />
      {listing.images[0] && <meta name="twitter:image" content={listing.images[0]} />}

      {/* Schema.org */}
      <script type="application/ld+json">
        {JSON.stringify(schema)}
      </script>
    </Helmet>
  );
};

export default ListingSEO;