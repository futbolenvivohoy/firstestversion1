import React from 'react';
import { Building2, Home, Warehouse, Hotel } from 'lucide-react';
import { Link } from 'react-router-dom';

const categories = [
  {
    id: 1,
    title: 'Wohnungen',
    description: 'Moderne Apartments und Wohnungen zur Miete',
    icon: Home,
    count: 234,
    color: 'bg-blue-50 text-blue-600',
  },
  {
    id: 2,
    title: 'Häuser',
    description: 'Einfamilienhäuser und Villen',
    icon: Building2,
    count: 156,
    color: 'bg-green-50 text-green-600',
  },
  {
    id: 3,
    title: 'Gewerbe',
    description: 'Büros, Läden und Gewerbeflächen',
    icon: Warehouse,
    count: 89,
    color: 'bg-purple-50 text-purple-600',
  },
  {
    id: 4,
    title: 'Ferienwohnungen',
    description: 'Temporäres Wohnen und Ferienapartments',
    icon: Hotel,
    count: 67,
    color: 'bg-orange-50 text-orange-600',
  },
];

const CategoryGrid = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-8">
      {categories.map((category) => (
        <Link
          key={category.id}
          to={`/category/${category.id}`}
          className="group bg-white rounded-lg shadow-sm p-6 hover:shadow-md transition-shadow"
        >
          <div className={`inline-flex p-3 rounded-lg ${category.color}`}>
            <category.icon className="h-6 w-6" />
          </div>
          <h3 className="mt-4 text-lg font-semibold text-gray-900 group-hover:text-indigo-600">
            {category.title}
          </h3>
          <p className="mt-1 text-sm text-gray-500">{category.description}</p>
          <div className="mt-2 text-sm font-medium text-indigo-600">
            {category.count} Angebote
          </div>
        </Link>
      ))}
    </div>
  );
};

export default CategoryGrid;