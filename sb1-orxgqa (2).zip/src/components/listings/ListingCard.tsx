import React from 'react';
import { Star } from 'lucide-react';

interface ListingCardProps {
  image: string;
  title: string;
  location: string;
  price: number;
}

const ListingCard = ({ image, title, location, price }: ListingCardProps) => {
  return (
    <div className="group h-full flex flex-col">
      <div className="relative aspect-[4/3] rounded-lg bg-gray-100 overflow-hidden">
        <img
          src={image}
          alt={title}
          className="absolute inset-0 h-full w-full object-cover transform group-hover:scale-105 transition-transform duration-200"
        />
        <div className="absolute top-2 right-2">
          <button className="p-1.5 rounded-full bg-white/80 hover:bg-white">
            <Star className="h-5 w-5 text-gray-600" />
          </button>
        </div>
      </div>
      <div className="flex-1 mt-3">
        <h3 className="text-lg font-semibold text-gray-900 line-clamp-2">{title}</h3>
        <p className="mt-1 text-sm text-gray-500">{location}</p>
        <p className="mt-1 font-medium text-indigo-600">€{price.toLocaleString()} / Monat</p>
      </div>
    </div>
  );
};

export default ListingCard;