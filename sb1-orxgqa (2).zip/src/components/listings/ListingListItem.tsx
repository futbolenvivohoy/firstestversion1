import React from 'react';
import { MapPin, Calendar, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

interface ListingListItemProps {
  id: string;
  image: string;
  title: string;
  location: string;
  price: number;
  features: string[];
  availableFrom: string;
}

const ListingListItem: React.FC<ListingListItemProps> = ({
  id,
  image,
  title,
  location,
  price,
  features,
  availableFrom,
}) => {
  return (
    <div className="bg-white rounded-lg shadow-sm overflow-hidden">
      <div className="flex">
        <div className="flex-shrink-0 w-48 h-48 relative">
          <img
            src={image}
            alt={title}
            className="w-full h-full object-cover"
          />
        </div>
        <div className="flex-1 p-6">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-gray-900">
              <Link to={`/listing/${id}`} className="hover:text-indigo-600">
                {title}
              </Link>
            </h3>
            <p className="text-lg font-semibold text-indigo-600">
              {price.toLocaleString()} € <span className="text-sm text-gray-500">/Monat</span>
            </p>
          </div>

          <div className="mt-2 flex items-center text-sm text-gray-500">
            <MapPin className="h-4 w-4 mr-1" />
            {location}
          </div>

          <div className="mt-4 flex items-center space-x-4">
            {features.map((feature, index) => (
              <span
                key={index}
                className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800"
              >
                {feature}
              </span>
            ))}
          </div>

          <div className="mt-4 flex items-center justify-between">
            <div className="flex items-center text-sm text-gray-500">
              <Calendar className="h-4 w-4 mr-1" />
              Verfügbar ab {new Date(availableFrom).toLocaleDateString()}
            </div>
            <Link
              to={`/listing/${id}`}
              className="inline-flex items-center text-sm font-medium text-indigo-600 hover:text-indigo-500"
            >
              Details ansehen
              <ArrowRight className="ml-1 h-4 w-4" />
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ListingListItem;