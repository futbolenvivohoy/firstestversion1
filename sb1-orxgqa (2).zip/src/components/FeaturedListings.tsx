import React from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import ListingCard from './listings/ListingCard';
import { CATEGORY_LISTINGS } from '../data/listings';

interface FeaturedListingsProps {
  title: string;
  category?: string;
}

const FeaturedListings: React.FC<FeaturedListingsProps> = ({ title, category = 'default' }) => {
  const listings = CATEGORY_LISTINGS[category as keyof typeof CATEGORY_LISTINGS];

  return (
    <section className="py-6 bg-white rounded-lg shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-gray-900">{title}</h2>
          <div className="flex space-x-2">
            <button className="p-2 rounded-full bg-gray-100 hover:bg-gray-200">
              <ChevronLeft className="h-5 w-5 text-gray-600" />
            </button>
            <button className="p-2 rounded-full bg-gray-100 hover:bg-gray-200">
              <ChevronRight className="h-5 w-5 text-gray-600" />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {listings.map((listing) => (
            <ListingCard key={listing.id} {...listing} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturedListings;