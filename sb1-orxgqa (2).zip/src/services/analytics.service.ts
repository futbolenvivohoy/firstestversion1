import api from './api';
import { AnalyticsData } from '../types';

export interface AnalyticsFilters {
  startDate: string;
  endDate: string;
  category?: string;
  location?: string;
}

export const analyticsService = {
  async getAnalytics(filters: AnalyticsFilters) {
    const { data } = await api.get<AnalyticsData>('/analytics', { params: filters });
    return data;
  },

  async getListingAnalytics(listingId: string) {
    const { data } = await api.get<AnalyticsData>(`/analytics/listing/${listingId}`);
    return data;
  },

  async getUserAnalytics(userId: string) {
    const { data } = await api.get<AnalyticsData>(`/analytics/user/${userId}`);
    return data;
  },

  async trackEvent(eventType: string, metadata: any) {
    await api.post('/analytics/event', { eventType, metadata });
  },
};