import api from './api';

export interface CacheConfig {
  key: string;
  ttl?: number;
  tags?: string[];
}

export const cacheService = {
  async get<T>(key: string): Promise<T | null> {
    const { data } = await api.get(`/cache/${key}`);
    return data;
  },

  async set<T>(key: string, value: T, config?: Partial<CacheConfig>) {
    await api.post('/cache', { key, value, ...config });
  },

  async invalidate(key: string) {
    await api.delete(`/cache/${key}`);
  },

  async invalidateByTag(tag: string) {
    await api.delete(`/cache/tag/${tag}`);
  },

  async clear() {
    await api.delete('/cache');
  },
};