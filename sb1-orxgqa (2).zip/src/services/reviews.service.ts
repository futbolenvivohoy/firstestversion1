import api from './api';
import { Review } from '../types';

export interface CreateReviewData {
  userId: string;
  listingId: string;
  rating: number;
  content: string;
}

export const reviewsService = {
  async getReviews(userId: string) {
    const { data } = await api.get<Review[]>(`/reviews/user/${userId}`);
    return data;
  },

  async createReview(reviewData: CreateReviewData) {
    const { data } = await api.post<Review>('/reviews', reviewData);
    return data;
  },

  async updateReview(reviewId: string, reviewData: Partial<CreateReviewData>) {
    const { data } = await api.put<Review>(`/reviews/${reviewId}`, reviewData);
    return data;
  },

  async deleteReview(reviewId: string) {
    await api.delete(`/reviews/${reviewId}`);
  },

  async reportReview(reviewId: string, reason: string) {
    await api.post(`/reviews/${reviewId}/report`, { reason });
  },
};