import api from './api';
import { Listing } from '../types';

export interface ListingFilters {
  category?: string;
  city?: string;
  priceMin?: number;
  priceMax?: number;
  status?: string;
  furnished?: boolean;
  petFriendly?: boolean;
  page?: number;
  limit?: number;
  sortBy?: string;
}

export interface CreateListingData {
  title: string;
  description: string;
  price: number;
  category: string;
  city: string;
  neighborhood: string;
  images: File[];
  features: string[];
  status: 'for_rent' | 'for_lease' | 'available';
}

export const listingsService = {
  async getListings(filters: ListingFilters) {
    const { data } = await api.get<{ listings: Listing[]; total: number }>('/listings', {
      params: filters,
    });
    return data;
  },

  async getListingById(id: string) {
    const { data } = await api.get<Listing>(`/listings/${id}`);
    return data;
  },

  async createListing(listingData: CreateListingData) {
    const formData = new FormData();
    Object.entries(listingData).forEach(([key, value]) => {
      if (key === 'images') {
        value.forEach((file: File) => {
          formData.append('images', file);
        });
      } else if (key === 'features') {
        formData.append('features', JSON.stringify(value));
      } else {
        formData.append(key, value.toString());
      }
    });

    const { data } = await api.post<Listing>('/listings', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    return data;
  },

  async updateListing(id: string, listingData: Partial<CreateListingData>) {
    const { data } = await api.put<Listing>(`/listings/${id}`, listingData);
    return data;
  },

  async deleteListing(id: string) {
    await api.delete(`/listings/${id}`);
  },

  async boostListing(id: string) {
    const { data } = await api.post<Listing>(`/listings/${id}/boost`);
    return data;
  },

  async getFeaturedListings() {
    const { data } = await api.get<Listing[]>('/listings/featured');
    return data;
  },

  async getNewListings() {
    const { data } = await api.get<Listing[]>('/listings/new');
    return data;
  },
};