import api from './api';

export interface SEOData {
  title: string;
  description: string;
  keywords: string[];
  schema: Record<string, any>;
}

export const seoService = {
  async generateSEOData(listingId: string): Promise<SEOData> {
    const { data } = await api.get<SEOData>(`/seo/listing/${listingId}`);
    return data;
  },

  async updateSEOData(listingId: string, seoData: Partial<SEOData>) {
    const { data } = await api.put<SEOData>(`/seo/listing/${listingId}`, seoData);
    return data;
  },

  async generateSchema(listingId: string) {
    const { data } = await api.get(`/seo/schema/${listingId}`);
    return data;
  },
};