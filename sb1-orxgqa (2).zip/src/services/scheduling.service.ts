import api from './api';

export interface ScheduleData {
  id: string;
  type: 'listing' | 'promotion' | 'ad';
  startDate: string;
  endDate: string;
  status: 'scheduled' | 'active' | 'completed';
}

export const schedulingService = {
  async scheduleContent(data: Omit<ScheduleData, 'id' | 'status'>) {
    const { data: response } = await api.post<ScheduleData>('/scheduling', data);
    return response;
  },

  async getScheduledContent() {
    const { data } = await api.get<ScheduleData[]>('/scheduling');
    return data;
  },

  async updateSchedule(id: string, updates: Partial<ScheduleData>) {
    const { data } = await api.put<ScheduleData>(`/scheduling/${id}`, updates);
    return data;
  },

  async cancelSchedule(id: string) {
    await api.delete(`/scheduling/${id}`);
  },
};