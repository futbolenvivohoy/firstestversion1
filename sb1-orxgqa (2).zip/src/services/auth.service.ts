import api from './api';
import { User } from '../types';

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface RegisterData {
  username: string;
  email: string;
  password: string;
  type: 'private' | 'agency';
  companyName?: string;
  address?: string;
  phone?: string;
}

export const authService = {
  async login(credentials: LoginCredentials) {
    const { data } = await api.post<{ token: string; user: User }>('/auth/login', credentials);
    localStorage.setItem('auth_token', data.token);
    return data;
  },

  async register(userData: RegisterData) {
    const { data } = await api.post<{ token: string; user: User }>('/auth/register', userData);
    localStorage.setItem('auth_token', data.token);
    return data;
  },

  async verifyEmail(token: string) {
    return api.post('/auth/verify-email', { token });
  },

  async forgotPassword(email: string) {
    return api.post('/auth/forgot-password', { email });
  },

  async resetPassword(token: string, password: string) {
    return api.post('/auth/reset-password', { token, password });
  },

  async getCurrentUser() {
    const { data } = await api.get<User>('/auth/me');
    return data;
  },

  logout() {
    localStorage.removeItem('auth_token');
  },
};