import api from './api';
import sharp from 'sharp';

export interface OptimizationResult {
  url: string;
  size: number;
  width: number;
  height: number;
  format: string;
}

export const optimizationService = {
  async optimizeImage(file: File): Promise<OptimizationResult> {
    const formData = new FormData();
    formData.append('image', file);

    const { data } = await api.post<OptimizationResult>('/optimization/image', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    return data;
  },

  async generateThumbnail(imageUrl: string, width: number, height: number) {
    const { data } = await api.post<OptimizationResult>('/optimization/thumbnail', {
      imageUrl,
      width,
      height,
    });
    return data;
  },

  async optimizeListingImages(images: File[]) {
    const formData = new FormData();
    images.forEach((image) => formData.append('images', image));

    const { data } = await api.post<OptimizationResult[]>('/optimization/listing-images', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    return data;
  },
};