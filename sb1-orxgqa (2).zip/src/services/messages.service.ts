import api from './api';
import { Message, Thread } from '../types';

export interface SendMessageData {
  recipientId: string;
  listingId: string;
  content: string;
}

export const messagesService = {
  async getThreads() {
    const { data } = await api.get<Thread[]>('/messages/threads');
    return data;
  },

  async getThread(threadId: string) {
    const { data } = await api.get<Thread>(`/messages/threads/${threadId}`);
    return data;
  },

  async sendMessage(messageData: SendMessageData) {
    const { data } = await api.post<Message>('/messages', messageData);
    return data;
  },

  async markThreadAsRead(threadId: string) {
    await api.put(`/messages/threads/${threadId}/read`);
  },

  async deleteThread(threadId: string) {
    await api.delete(`/messages/threads/${threadId}`);
  },
};