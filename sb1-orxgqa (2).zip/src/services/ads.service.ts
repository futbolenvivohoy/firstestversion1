import api from './api';
import { Ad } from '../types';

export interface CreateAdData {
  title: string;
  description: string;
  budget: number;
  startDate: string;
  endDate: string;
  targetAudience: {
    locations: string[];
    categories: string[];
    priceRange?: {
      min: number;
      max: number;
    };
  };
  media: File[];
}

export const adsService = {
  async createAd(data: CreateAdData) {
    const formData = new FormData();
    Object.entries(data).forEach(([key, value]) => {
      if (key === 'media') {
        value.forEach((file: File) => {
          formData.append('media', file);
        });
      } else if (key === 'targetAudience') {
        formData.append('targetAudience', JSON.stringify(value));
      } else {
        formData.append(key, value.toString());
      }
    });

    const { data: response } = await api.post<Ad>('/ads', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    return response;
  },

  async getAds(userId: string) {
    const { data } = await api.get<Ad[]>(`/ads/user/${userId}`);
    return data;
  },

  async updateAd(adId: string, updates: Partial<CreateAdData>) {
    const { data } = await api.put<Ad>(`/ads/${adId}`, updates);
    return data;
  },

  async pauseAd(adId: string) {
    const { data } = await api.put<Ad>(`/ads/${adId}/pause`);
    return data;
  },

  async resumeAd(adId: string) {
    const { data } = await api.put<Ad>(`/ads/${adId}/resume`);
    return data;
  },

  async getAdStats(adId: string) {
    const { data } = await api.get(`/ads/${adId}/stats`);
    return data;
  },
};