import api from './api';
import { Listing } from '../types';

export interface RecommendationParams {
  userId?: string;
  category?: string;
  location?: string;
  priceRange?: {
    min: number;
    max: number;
  };
}

export const recommendationService = {
  async getRecommendations(params: RecommendationParams) {
    const { data } = await api.get<Listing[]>('/recommendations', { params });
    return data;
  },

  async getPersonalizedListings(userId: string) {
    const { data } = await api.get<Listing[]>(`/recommendations/user/${userId}`);
    return data;
  },

  async getSimilarListings(listingId: string) {
    const { data } = await api.get<Listing[]>(`/recommendations/similar/${listingId}`);
    return data;
  },

  async trackUserPreferences(userId: string, preferences: any) {
    await api.post(`/recommendations/preferences/${userId}`, preferences);
  },
};