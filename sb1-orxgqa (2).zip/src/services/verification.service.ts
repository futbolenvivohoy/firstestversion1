import api from './api';

export interface VerificationRequest {
  userId: string;
  documents: File[];
  type: 'agency' | 'private';
  companyDetails?: {
    registrationNumber: string;
    taxId: string;
    licenseNumber?: string;
  };
}

export const verificationService = {
  async requestVerification(data: VerificationRequest) {
    const formData = new FormData();
    formData.append('userId', data.userId);
    formData.append('type', data.type);
    
    data.documents.forEach((doc) => {
      formData.append('documents', doc);
    });

    if (data.companyDetails) {
      formData.append('companyDetails', JSON.stringify(data.companyDetails));
    }

    const { data: response } = await api.post('/verification/request', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    return response;
  },

  async getVerificationStatus(userId: string) {
    const { data } = await api.get(`/verification/status/${userId}`);
    return data;
  },

  async approveVerification(requestId: string) {
    const { data } = await api.post(`/verification/${requestId}/approve`);
    return data;
  },

  async rejectVerification(requestId: string, reason: string) {
    const { data } = await api.post(`/verification/${requestId}/reject`, { reason });
    return data;
  },
};