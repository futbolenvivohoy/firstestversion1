import api from './api';

export interface ModerationResult {
  approved: boolean;
  flags: string[];
  score: number;
  reason?: string;
}

export const moderationService = {
  async moderateContent(content: string): Promise<ModerationResult> {
    const { data } = await api.post<ModerationResult>('/moderation/check', { content });
    return data;
  },

  async moderateImage(imageUrl: string): Promise<ModerationResult> {
    const { data } = await api.post<ModerationResult>('/moderation/image', { imageUrl });
    return data;
  },

  async reportContent(contentId: string, reason: string) {
    await api.post('/moderation/report', { contentId, reason });
  },

  async getReportedContent() {
    const { data } = await api.get('/moderation/reports');
    return data;
  },
};