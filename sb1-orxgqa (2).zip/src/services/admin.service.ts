import api from './api';
import { User, Listing, Category, AnalyticsData } from '../types';

export const adminService = {
  // User Management
  async getUsers(filters: any) {
    const { data } = await api.get<{ users: User[]; total: number }>('/admin/users', {
      params: filters,
    });
    return data;
  },

  async updateUserStatus(userId: string, status: 'active' | 'suspended') {
    const { data } = await api.put<User>(`/admin/users/${userId}/status`, { status });
    return data;
  },

  // Listing Management
  async getPendingListings() {
    const { data } = await api.get<Listing[]>('/admin/listings/pending');
    return data;
  },

  async approveListing(listingId: string) {
    const { data } = await api.put<Listing>(`/admin/listings/${listingId}/approve`);
    return data;
  },

  async rejectListing(listingId: string, reason: string) {
    const { data } = await api.put<Listing>(`/admin/listings/${listingId}/reject`, { reason });
    return data;
  },

  // Category Management
  async getCategories() {
    const { data } = await api.get<Category[]>('/admin/categories');
    return data;
  },

  async createCategory(categoryData: Partial<Category>) {
    const { data } = await api.post<Category>('/admin/categories', categoryData);
    return data;
  },

  async updateCategory(categoryId: string, categoryData: Partial<Category>) {
    const { data } = await api.put<Category>(`/admin/categories/${categoryId}`, categoryData);
    return data;
  },

  async deleteCategory(categoryId: string) {
    await api.delete(`/admin/categories/${categoryId}`);
  },

  // Analytics
  async getAnalytics(timeRange: string) {
    const { data } = await api.get<AnalyticsData>('/admin/analytics', {
      params: { timeRange },
    });
    return data;
  },

  // Moderation
  async getReportedContent() {
    const { data } = await api.get('/admin/moderation/reported');
    return data;
  },

  async resolveReport(reportId: string, action: 'approve' | 'remove') {
    await api.put(`/admin/moderation/reports/${reportId}`, { action });
  },
};