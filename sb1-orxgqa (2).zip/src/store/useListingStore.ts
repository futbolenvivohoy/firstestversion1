import { create } from 'zustand';
import { Listing } from '../types';
import { listingsService, ListingFilters } from '../services/listings.service';

interface ListingState {
  listings: Listing[];
  featuredListings: Listing[];
  newListings: Listing[];
  currentListing: Listing | null;
  loading: boolean;
  error: string | null;
  filters: ListingFilters;
  total: number;
  getListings: (filters?: ListingFilters) => Promise<void>;
  getFeaturedListings: () => Promise<void>;
  getNewListings: () => Promise<void>;
  getListing: (id: string) => Promise<void>;
  createListing: (data: any) => Promise<void>;
  updateListing: (id: string, data: any) => Promise<void>;
  deleteListing: (id: string) => Promise<void>;
  setFilters: (filters: ListingFilters) => void;
  clearError: () => void;
}

export const useListingStore = create<ListingState>((set, get) => ({
  listings: [],
  featuredListings: [],
  newListings: [],
  currentListing: null,
  loading: false,
  error: null,
  filters: {},
  total: 0,

  getListings: async (filters) => {
    try {
      set({ loading: true, error: null });
      const { listings, total } = await listingsService.getListings(filters || get().filters);
      set({ listings, total });
    } catch (error) {
      set({ error: 'Fehler beim Laden der Anzeigen' });
    } finally {
      set({ loading: false });
    }
  },

  getFeaturedListings: async () => {
    try {
      const featuredListings = await listingsService.getFeaturedListings();
      set({ featuredListings });
    } catch (error) {
      set({ error: 'Fehler beim Laden der Featured Anzeigen' });
    }
  },

  getNewListings: async () => {
    try {
      const newListings = await listingsService.getNewListings();
      set({ newListings });
    } catch (error) {
      set({ error: 'Fehler beim Laden der neuen Anzeigen' });
    }
  },

  getListing: async (id: string) => {
    try {
      set({ loading: true, error: null });
      const listing = await listingsService.getListingById(id);
      set({ currentListing: listing });
    } catch (error) {
      set({ error: 'Fehler beim Laden der Anzeige' });
    } finally {
      set({ loading: false });
    }
  },

  createListing: async (data) => {
    try {
      set({ loading: true, error: null });
      await listingsService.createListing(data);
      get().getListings();
    } catch (error) {
      set({ error: 'Fehler beim Erstellen der Anzeige' });
    } finally {
      set({ loading: false });
    }
  },

  updateListing: async (id, data) => {
    try {
      set({ loading: true, error: null });
      await listingsService.updateListing(id, data);
      get().getListings();
    } catch (error) {
      set({ error: 'Fehler beim Aktualisieren der Anzeige' });
    } finally {
      set({ loading: false });
    }
  },

  deleteListing: async (id) => {
    try {
      set({ loading: true, error: null });
      await listingsService.deleteListing(id);
      get().getListings();
    } catch (error) {
      set({ error: 'Fehler beim Löschen der Anzeige' });
    } finally {
      set({ loading: false });
    }
  },

  setFilters: (filters) => set({ filters }),
  clearError: () => set({ error: null }),
}));