import { create } from 'zustand';
import { Message, Thread } from '../types';
import { messagesService } from '../services/messages.service';

interface MessageState {
  threads: Thread[];
  currentThread: Thread | null;
  loading: boolean;
  error: string | null;
  getThreads: () => Promise<void>;
  getThread: (threadId: string) => Promise<void>;
  sendMessage: (data: { recipientId: string; listingId: string; content: string }) => Promise<void>;
  markThreadAsRead: (threadId: string) => Promise<void>;
  deleteThread: (threadId: string) => Promise<void>;
  clearError: () => void;
}

export const useMessageStore = create<MessageState>((set, get) => ({
  threads: [],
  currentThread: null,
  loading: false,
  error: null,

  getThreads: async () => {
    try {
      set({ loading: true, error: null });
      const threads = await messagesService.getThreads();
      set({ threads });
    } catch (error) {
      set({ error: 'Fehler beim Laden der Nachrichten' });
    } finally {
      set({ loading: false });
    }
  },

  getThread: async (threadId: string) => {
    try {
      set({ loading: true, error: null });
      const thread = await messagesService.getThread(threadId);
      set({ currentThread: thread });
    } catch (error) {
      set({ error: 'Fehler beim Laden des Nachrichtenverlaufs' });
    } finally {
      set({ loading: false });
    }
  },

  sendMessage: async (data) => {
    try {
      set({ loading: true, error: null });
      await messagesService.sendMessage(data);
      if (get().currentThread) {
        get().getThread(get().currentThread.id);
      }
    } catch (error) {
      set({ error: 'Fehler beim Senden der Nachricht' });
    } finally {
      set({ loading: false });
    }
  },

  markThreadAsRead: async (threadId: string) => {
    try {
      await messagesService.markThreadAsRead(threadId);
      get().getThreads();
    } catch (error) {
      set({ error: 'Fehler beim Markieren als gelesen' });
    }
  },

  deleteThread: async (threadId: string) => {
    try {
      set({ loading: true, error: null });
      await messagesService.deleteThread(threadId);
      get().getThreads();
    } catch (error) {
      set({ error: 'Fehler beim Löschen des Nachrichtenverlaufs' });
    } finally {
      set({ loading: false });
    }
  },

  clearError: () => set({ error: null }),
}));