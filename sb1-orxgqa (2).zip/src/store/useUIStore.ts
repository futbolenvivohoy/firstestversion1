import { create } from 'zustand';

interface UIState {
  sidebarOpen: boolean;
  searchFiltersOpen: boolean;
  currentModal: string | null;
  notifications: Array<{
    id: string;
    type: 'success' | 'error' | 'info';
    message: string;
  }>;
  toggleSidebar: () => void;
  toggleSearchFilters: () => void;
  openModal: (modalId: string) => void;
  closeModal: () => void;
  addNotification: (type: 'success' | 'error' | 'info', message: string) => void;
  removeNotification: (id: string) => void;
}

export const useUIStore = create<UIState>((set) => ({
  sidebarOpen: false,
  searchFiltersOpen: false,
  currentModal: null,
  notifications: [],

  toggleSidebar: () =>
    set((state) => ({ sidebarOpen: !state.sidebarOpen })),

  toggleSearchFilters: () =>
    set((state) => ({ searchFiltersOpen: !state.searchFiltersOpen })),

  openModal: (modalId: string) =>
    set({ currentModal: modalId }),

  closeModal: () =>
    set({ currentModal: null }),

  addNotification: (type, message) =>
    set((state) => ({
      notifications: [
        ...state.notifications,
        { id: Date.now().toString(), type, message },
      ],
    })),

  removeNotification: (id) =>
    set((state) => ({
      notifications: state.notifications.filter((n) => n.id !== id),
    })),
}));