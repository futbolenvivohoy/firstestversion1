import { create } from 'zustand';
import { User, Listing, Category, AnalyticsData } from '../types';
import { adminService } from '../services/admin.service';

interface AdminState {
  users: User[];
  pendingListings: Listing[];
  categories: Category[];
  analytics: AnalyticsData | null;
  loading: boolean;
  error: string | null;
  totalUsers: number;
  getUsers: (filters?: any) => Promise<void>;
  updateUserStatus: (userId: string, status: 'active' | 'suspended') => Promise<void>;
  getPendingListings: () => Promise<void>;
  approveListing: (listingId: string) => Promise<void>;
  rejectListing: (listingId: string, reason: string) => Promise<void>;
  getCategories: () => Promise<void>;
  createCategory: (data: Partial<Category>) => Promise<void>;
  updateCategory: (categoryId: string, data: Partial<Category>) => Promise<void>;
  deleteCategory: (categoryId: string) => Promise<void>;
  getAnalytics: (timeRange: string) => Promise<void>;
  clearError: () => void;
}

export const useAdminStore = create<AdminState>((set, get) => ({
  users: [],
  pendingListings: [],
  categories: [],
  analytics: null,
  loading: false,
  error: null,
  totalUsers: 0,

  getUsers: async (filters) => {
    try {
      set({ loading: true, error: null });
      const { users, total } = await adminService.getUsers(filters);
      set({ users, totalUsers: total });
    } catch (error) {
      set({ error: 'Fehler beim Laden der Benutzer' });
    } finally {
      set({ loading: false });
    }
  },

  updateUserStatus: async (userId, status) => {
    try {
      set({ loading: true, error: null });
      await adminService.updateUserStatus(userId, status);
      get().getUsers();
    } catch (error) {
      set({ error: 'Fehler beim Aktualisieren des Benutzerstatus' });
    } finally {
      set({ loading: false });
    }
  },

  getPendingListings: async () => {
    try {
      set({ loading: true, error: null });
      const listings = await adminService.getPendingListings();
      set({ pendingListings: listings });
    } catch (error) {
      set({ error: 'Fehler beim Laden der ausstehenden Anzeigen' });
    } finally {
      set({ loading: false });
    }
  },

  approveListing: async (listingId) => {
    try {
      set({ loading: true, error: null });
      await adminService.approveListing(listingId);
      get().getPendingListings();
    } catch (error) {
      set({ error: 'Fehler beim Genehmigen der Anzeige' });
    } finally {
      set({ loading: false });
    }
  },

  rejectListing: async (listingId, reason) => {
    try {
      set({ loading: true, error: null });
      await adminService.rejectListing(listingId, reason);
      get().getPendingListings();
    } catch (error) {
      set({ error: 'Fehler beim Ablehnen der Anzeige' });
    } finally {
      set({ loading: false });
    }
  },

  getCategories: async () => {
    try {
      set({ loading: true, error: null });
      const categories = await adminService.getCategories();
      set({ categories });
    } catch (error) {
      set({ error: 'Fehler beim Laden der Kategorien' });
    } finally {
      set({ loading: false });
    }
  },

  createCategory: async (data) => {
    try {
      set({ loading: true, error: null });
      await adminService.createCategory(data);
      get().getCategories();
    } catch (error) {
      set({ error: 'Fehler beim Erstellen der Kategorie' });
    } finally {
      set({ loading: false });
    }
  },

  updateCategory: async (categoryId, data) => {
    try {
      set({ loading: true, error: null });
      await adminService.updateCategory(categoryId, data);
      get().getCategories();
    } catch (error) {
      set({ error: 'Fehler beim Aktualisieren der Kategorie' });
    } finally {
      set({ loading: false });
    }
  },

  deleteCategory: async (categoryId) => {
    try {
      set({ loading: true, error: null });
      await adminService.deleteCategory(categoryId);
      get().getCategories();
    } catch (error) {
      set({ error: 'Fehler beim Löschen der Kategorie' });
    } finally {
      set({ loading: false });
    }
  },

  getAnalytics: async (timeRange) => {
    try {
      set({ loading: true, error: null });
      const analytics = await adminService.getAnalytics(timeRange);
      set({ analytics });
    } catch (error) {
      set({ error: 'Fehler beim Laden der Analytics' });
    } finally {
      set({ loading: false });
    }
  },

  clearError: () => set({ error: null }),
}));