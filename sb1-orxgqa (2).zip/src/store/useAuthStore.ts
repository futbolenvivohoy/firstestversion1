import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { User } from '../types';
import { authService } from '../services/auth.service';

interface AuthState {
  user: User | null;
  token: string | null;
  loading: boolean;
  error: string | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (userData: any) => Promise<void>;
  logout: () => void;
  clearError: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      token: null,
      loading: false,
      error: null,
      isAuthenticated: false,

      login: async (email: string, password: string) => {
        try {
          set({ loading: true, error: null });
          const { token, user } = await authService.login({ email, password });
          set({ user, token, isAuthenticated: true });
        } catch (error) {
          set({ error: 'Login fehlgeschlagen' });
        } finally {
          set({ loading: false });
        }
      },

      register: async (userData) => {
        try {
          set({ loading: true, error: null });
          const { token, user } = await authService.register(userData);
          set({ user, token, isAuthenticated: true });
        } catch (error) {
          set({ error: 'Registrierung fehlgeschlagen' });
        } finally {
          set({ loading: false });
        }
      },

      logout: () => {
        authService.logout();
        set({ user: null, token: null, isAuthenticated: false });
      },

      clearError: () => set({ error: null }),
    }),
    {
      name: 'auth-storage',
      partialize: (state) => ({ token: state.token }),
    }
  )
);